# Avelis AI — Connected interactive prototype (GitHub Pages)

Avelis AI / Ditheka Intelligence. Authentic brand logos are included.

## What really works inside the browser
- 11-panel Command Centre with connected Business and Developer Workspaces
- Integration metadata intake (no URL is fetched or scanned)
- Local approvals, synthetic incidents, scenario-based simulation records
- Unified assistant preview: typed questions with limited rule-based contextual answers across Business, Developer, and Security modes
- Seven-step onboarding demonstration with local progress and a proposed pricing estimator
- Downloadable JSON reports and CSV audit history
- Locally stored sample records and state, with Reset Demo control

## Important limitations
This is a **front-end prototype**, not a deployed enterprise AI backend. The sample connector, incident and simulation are fictional. The demo does not authenticate users, send invitations, connect to APIs/MCP servers, call generative AI, monitor telemetry, actually simulate code, enforce security policies, process payments, or provision enterprise tenants. Do not enter confidential information. Local demo data are stored in the browser, not securely synchronized.

The proposed plans are not active subscriptions. A production version requires a server application, identity provider, secure credentials management, audit store, integration runtime, AI model API and verified customer data access.

## Publish
Upload the separate, single-file `index.html` to the root of GitHub repository `Bliuew/avelis-ai`, replacing the old 33KB file. GitHub Pages main/(root) will republish after commit.

For editing in the future, use this ZIP's separately organized assets, HTML, CSS and JavaScript instead.
