Original public main backup — base f097148f462f3d9cec67efd33765d7b1286d0b56.
Created before implementation. No confidential uploaded artwork or reviewer data
is present in this backup.

original-main-index.html is the original byte-identical self-contained page.
original-main.bundle contains the original main Git history. To restore a local
checkout: git clone original-main.bundle restored-avelis

These are backup artifacts, not runtime dependencies of the website.
