// Server adapters are intentionally unconfigured. Credentials must stay server-side.
export const contract = {
  version: "1.0",
  services: [
    "authentication",
    "tenancy",
    "permissions",
    "ai",
    "messaging",
    "telephony",
    "payments",
    "audit",
  ],
};
export class BackendAdapter {
  async request(service, payload) {
    if (!contract.services.includes(service)) throw Error("Unknown service.");
    throw Error(
      `${service} requires an authenticated server deployment. No external request was made.`,
    );
  }
}
export const advisorDataset = (s) => ({
  version: "1.0",
  headers: [
    "date",
    "transaction",
    "status",
    "amount_cad",
    "fee_cad",
    "net_cad",
  ],
  rows: s.sharim.transactions.map((t) => [
    t.at.slice(0, 10),
    t.id,
    t.status,
    String(t.status === "Approved" ? t.amount / 100 : 0),
    String(t.fee / 100),
    String(t.status === "Approved" ? (t.amount - t.fee) / 100 : 0),
  ]),
  source: "Connected ecosystem · fictional transactions",
  sample: true,
  metric: "amount_cad",
  group: "status",
});

/** Optional server transport. Disabled unless explicitly configured by the deployer.
 * The server must authenticate its HttpOnly session, enforce tenant/role policies,
 * validate CSRF, store all service credentials and authorize each operation.
 * Passing configuration here never establishes authentication or authorization.
 */
export class ServerAdapter {
  constructor({
    baseUrl = "",
    enabled = false,
    csrfToken = "",
    fetchImpl = globalThis.fetch,
  } = {}) {
    this.enabled = enabled;
    this.csrfToken = csrfToken;
    this.fetchImpl = fetchImpl;
    this.baseUrl = "";
    if (baseUrl) {
      const url = new URL(baseUrl);
      if (
        url.protocol !== "https:" ||
        url.username ||
        url.password ||
        url.search ||
        url.hash
      )
        throw Error(
          "Use an HTTPS backend origin without embedded credentials or query parameters.",
        );
      this.baseUrl = url.origin;
    }
  }
  async request(service, payload) {
    if (!contract.services.includes(service))
      throw Error("Unknown backend service.");
    if (!this.enabled || !this.baseUrl)
      throw Error("Backend adapter is not configured. No request was made.");
    if (!this.csrfToken)
      throw Error("A server-issued session CSRF token is required.");
    const body = JSON.stringify({ version: contract.version, payload });
    if (body.length > 100000)
      throw Error("Backend request exceeds the prototype adapter limit.");
    const response = await this.fetchImpl(`${this.baseUrl}/api/v1/${service}`, {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
        "X-CSRF-Token": this.csrfToken,
      },
      body,
    });
    if (!response.ok)
      throw Error(
        `Backend request was not confirmed (HTTP ${response.status}).`,
      );
    if (!response.headers.get("content-type")?.includes("application/json"))
      throw Error("Backend returned an unexpected response format.");
    const result = await response.json();
    if (result.version !== "1.0")
      throw Error("Unsupported backend response version.");
    if (
      service === "ai" &&
      (!result.model ||
        typeof result.answer !== "string" ||
        !Array.isArray(result.evidence))
    )
      throw Error(
        "Model responses must provide model provenance, answer text and evidence references.",
      );
    return result;
  }
}
