export const KEY = "avelis-ecosystem-v1";
export const id = (p) => `${p}-${globalThis.crypto.randomUUID()}`;
export const date = () => new Date().toISOString();
export const text = (v, max = 300) => {
  const s = String(v ?? "").trim();
  if (!s || s.length > max) throw Error(`Enter 1–${max} characters.`);
  return s;
};
export const integer = (v, min = 0, max = 100000000) => {
  const n = Number(v);
  if (!Number.isSafeInteger(n) || n < min || n > max)
    throw Error(`Enter a whole number from ${min} to ${max}.`);
  return n;
};
export function seed() {
  return {
    version: 1,
    revision: 0,
    theme: "light",
    progress: [],
    mode: "guided",
    ama: {
      prospects: [
        {
          id: "P-1",
          company: "Cedar & Finch Studio",
          name: "Alex Example",
          industry: "Design",
          location: "Toronto",
          size: 24,
          role: "Director",
          status: "Fictional email available",
          email: "alex@cedar.example",
          signals: ["Hiring operations lead", "New project announcement"],
          source: "Fictional directory",
        },
        {
          id: "P-2",
          company: "Northlight Foods",
          name: "Morgan Sample",
          industry: "Food",
          location: "Vancouver",
          size: 85,
          role: "Operations",
          status: "Consent pending",
          email: "",
          signals: ["Opening a fictional location"],
          source: "Fictional directory",
        },
        {
          id: "P-3",
          company: "Ivory Works",
          name: "Sam Demo",
          industry: "Technology",
          location: "Montreal",
          size: 140,
          role: "Founder",
          status: "Fictional email available",
          email: "sam@ivory.example",
          signals: ["Evaluating CRM", "Hiring sales team"],
          source: "Approved CSV",
        },
      ],
      saved: [],
      contacts: [],
      accounts: [],
      opportunities: [],
      stages: ["Discovery", "Qualified", "Proposal", "Won", "Lost"],
      tasks: [],
      calls: [],
      activeCall: null,
      channels: [
        {
          id: "CH-1",
          name: "revenue",
          private: false,
          workspace: "Demo company",
        },
        {
          id: "CH-2",
          name: "leadership",
          private: true,
          workspace: "Demo company",
        },
        {
          id: "CH-3",
          name: "Direct · Jordan Example",
          private: true,
          workspace: "Demo company",
        },
      ],
      messages: [
        {
          id: "M-1",
          channel: "CH-1",
          body: "Welcome. All records and messages in this workspace are fictional and local to this browser.",
          at: date(),
          reactions: 0,
          pinned: true,
        },
      ],
      workflows: [],
      invoices: [],
      quotes: [],
      orders: [],
      meetings: [],
      criteria: {
        questions: 25,
        objections: 25,
        commitments: 25,
        followup: 25,
      },
      members: [
        { name: "Jordan Example", department: "Revenue" },
        { name: "Taylor Demo", department: "Operations" },
      ],
      queues: [
        { id: "Q-1", name: "New enquiries", items: [] },
        { id: "Q-2", name: "Customer callbacks", items: [] },
      ],
      projects: [
        {
          id: "PR-1",
          name: "Fictional customer onboarding",
          deadline: "2026-12-15",
        },
      ],
    },
    sharim: {
      connected: false,
      notifications: [],
      merchant: "Fictional Demo Merchant",
      feeBps: 250,
      fixedFee: 30,
      transactions: [],
      requests: [],
      benefit: 1,
      alerts: true,
      permissions: true,
      mode: "connected",
      modules: ["Essentials", "Ritual", "Curated", "Founder’s Circle"].map(
        (name, i) => ({
          id: "MOD-" + (i + 1),
          name,
          attached: true,
          frozen: false,
          limit: 250000,
          spent: 0,
        }),
      ),
    },
    events: [],
  };
}
export function read(storage) {
  try {
    const raw = storage.getItem(KEY);
    if (!raw) return seed();
    const s = JSON.parse(raw);
    if (s.version !== 1 || !s.ama || !s.sharim || !Array.isArray(s.events))
      throw Error();
    const defaults = seed();
    s.ama = { ...defaults.ama, ...s.ama };
    s.sharim = { ...defaults.sharim, ...s.sharim };
    for (const ns of ["ama", "sharim"])
      for (const [k, v] of Object.entries(defaults[ns]))
        if (Array.isArray(v) && !Array.isArray(s[ns][k])) s[ns][k] = v;
    for (const c of s.ama.contacts) {
      if (!c.account || !s.ama.accounts.some((a) => a.id === c.account)) {
        let a = s.ama.accounts.find(
          (a) => a.name.toLowerCase() === String(c.company).toLowerCase(),
        );
        if (!a) {
          a = {
            id: "ACCT-MIG-" + c.id,
            name: c.company,
            industry: "Unspecified",
            location: "Unspecified",
            size: 0,
          };
          s.ama.accounts.push(a);
        }
        c.account = a.id;
      }
    }
    return s;
  } catch {
    return seed();
  }
}
export class Store {
  constructor(storage) {
    this.storage = storage;
    this.state = read(storage);
    this.listeners = [];
    this.warning = "";
  }
  save() {
    try {
      this.storage.setItem(KEY, JSON.stringify(this.state));
      this.warning = "";
    } catch {
      this.warning =
        "Storage unavailable or full. Changes remain in memory only; export your report before leaving.";
    }
  }
  change(type, fn, detail = {}) {
    const old = structuredClone(this.state);
    try {
      const out = fn(this.state);
      this.state.revision++;
      const records = [];
      for (const ns of ["ama", "sharim"])
        for (const [collection, items] of Object.entries(this.state[ns])) {
          if (!Array.isArray(items)) continue;
          const previous = old[ns][collection] || [];
          for (const item of items) {
            if (!item?.id) continue;
            const before = previous.find((x) => x.id === item.id);
            if (!before || JSON.stringify(before) !== JSON.stringify(item))
              records.push({ namespace: ns, collection, id: item.id });
          }
        }
      this.state.events.push({
        id: id("EV"),
        version: "1.0",
        type,
        at: date(),
        actor: "fictional-reviewer",
        detail: { ...detail, records },
      });
      this.save();
      this.listeners.forEach((f) => f());
      return out;
    } catch (e) {
      this.state = old;
      throw e;
    }
  }
  reset() {
    this.state = seed();
    try {
      this.storage.removeItem?.("avelis-ecosystem-advisor-v1");
    } catch {}
    this.save();
    this.listeners.forEach((f) => f());
  }
}
export function csv(rows) {
  return rows
    .map((r) =>
      r
        .map((v) => {
          let s = String(v ?? "");
          if (/^\s*[=+@-]/.test(s)) s = "'" + s;
          return '"' + s.replaceAll('"', '""') + '"';
        })
        .join(","),
    )
    .join("\r\n");
}
export function parseCSV(input) {
  let rows = [],
    r = [],
    s = "",
    q = false;
  input = String(input).replace(/^\uFEFF/, "");
  for (let i = 0; i < input.length; i++) {
    let c = input[i];
    if (q) {
      if (c === '"' && input[i + 1] === '"') {
        s += '"';
        i++;
      } else if (c === '"') q = false;
      else s += c;
    } else if (c === '"') {
      if (s) throw Error("Invalid CSV quotes.");
      q = true;
    } else if (c === ",") {
      r.push(s);
      s = "";
    } else if (c === "\n") {
      r.push(s.replace(/\r$/, ""));
      rows.push(r);
      r = [];
      s = "";
    } else s += c;
  }
  if (q) throw Error("Unclosed CSV quote.");
  if (s || r.length) {
    r.push(s.replace(/\r$/, ""));
    rows.push(r);
  }
  return rows.filter((r) => r.some(Boolean));
}
export const download = (name, body, type = "text/plain") => {
  const u = URL.createObjectURL(new Blob([body], { type }));
  const a = document.createElement("a");
  a.href = u;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(u), 1000);
};
