const escape = (v) =>
  String(v ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
const money = (n) =>
  new Intl.NumberFormat("en-CA", { style: "currency", currency: "CAD" }).format(
    n / 100,
  );
const page = (title, body) =>
  `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escape(title)}</title><style>body{max-width:980px;margin:45px auto;padding:0 24px;color:#26372c;background:#fbfaf5;font:15px/1.7 system-ui,sans-serif}h1,h2{font-family:Georgia,serif;font-weight:400}h1{font-size:36px}h2{margin-top:32px}header{border-bottom:2px solid #ba9a60;padding-bottom:20px}p,td{overflow-wrap:anywhere}table{border-collapse:collapse;width:100%;margin:20px 0}td,th{padding:12px 8px;text-align:left;border-bottom:1px solid #d7ddd5}.disclosure{padding:16px;background:#e9efe8;border-left:3px solid #28543c}.totals{font-size:22px}small{color:#657267}@media print{body{margin:0;max-width:none}}</style></head><body><header><small>AVELIS AI · CONNECTED ECOSYSTEM</small><h1>${escape(title)}</h1><small>Generated ${escape(new Date().toISOString())}</small></header><p class="disclosure">Fictional demonstration records. This report records browser-local functionality and simulated events. No money moved, no telephone call was placed, no multi-user message was sent and no AI model was used.</p>${body}<footer><p><small>Kubézema → Umoja Network → Ditheka Intelligence → Avelis AI & Amā. Sharim is an optional integration under Maarah. Browser records can be edited and are not certified audit evidence.</small></p></footer></body></html>`;
export function invoiceHTML(s, i, total, kind = "invoice") {
  const c = s.ama.contacts.find((c) => c.id === i.contact);
  return page(
    "Amā · Fictional " + kind,
    `<p><b>${escape(c?.company)}</b><br>${escape(c?.name)}<br>${escape(i.id)} · ${escape(i.status)}</p><table><thead><tr><th>Description</th><th>Quantity</th><th>Unit price</th><th>Line total</th></tr></thead><tbody>${i.lines.map((l) => `<tr><td>${escape(l.description)}</td><td>${l.quantity}</td><td>${money(l.unit)}</td><td>${money(l.quantity * l.unit)}</td></tr>`).join("")}</tbody></table><p class="totals">Total: ${money(total)} · Received: ${money(i.paid)} · Outstanding: ${money(total - i.paid)}</p><p>Related opportunity: ${escape(i.opportunity || "None")}</p>`,
  );
}
export function receiptHTML(s, t) {
  return page(
    "Sharim · Fictional transaction receipt",
    `<p><b>${escape(s.sharim.merchant)}</b><br>${escape(t.id)}<br>Invoice ${escape(t.invoice)}<br>${escape(t.at)}</p><table><tbody>${[
      ["State", t.status],
      ["Gross amount", money(t.amount)],
      ["Current demo fee", money(t.fee)],
      [
        "Current net settlement",
        money(t.status === "Approved" ? t.amount - t.fee : 0),
      ],
      ["Reward points", t.points],
      ["Placeholder module", t.module],
      ["Idempotency key", t.key],
    ]
      .map(([k, v]) => `<tr><th>${escape(k)}</th><td>${escape(v)}</td></tr>`)
      .join(
        "",
      )}</tbody></table>${t.status === "Refunded" ? "<p>Full simulated refund: invoice receipt, module spend, points and demo fee reversed.</p>" : ""}`,
  );
}
export function investorHTML(s, metrics, steps) {
  return page(
    "Investor demonstration report",
    `<h2>Calculated business results</h2><table><tbody>${Object.entries(metrics)
      .map(
        ([k, v]) =>
          `<tr><th>${escape(k)}</th><td>${["pipeline", "weighted", "invoiced", "paid"].includes(k) ? money(v) : escape(v)}</td></tr>`,
      )
      .join(
        "",
      )}</tbody></table><h2>Demonstration progress</h2><table><tbody>${steps.map(([, label, key], i) => `<tr><td>${i + 1}</td><td>${escape(label)}</td><td>${s.progress.includes(key) ? "Completed" : "Not yet recorded"}</td></tr>`).join("")}</tbody></table><h2>Connected evidence</h2><p>${s.ama.contacts.length} contacts · ${s.ama.opportunities.length} opportunities · ${s.ama.calls.length} completed calls · ${s.ama.tasks.length} tasks · ${s.ama.workflows.length} workflows · ${s.ama.invoices.length} invoices · ${s.sharim.transactions.length} transactions.</p><p>Sharim integration: ${s.sharim.connected ? "Connected" : "Disconnected"}.</p><h2>Latest versioned events</h2><table><thead><tr><th>Time</th><th>Event</th><th>Record references</th></tr></thead><tbody>${s.events
      .slice(-30)
      .reverse()
      .map(
        (e) =>
          `<tr><td>${escape(e.at)}</td><td>${escape(e.type)}</td><td>${escape((e.detail.records || []).map((r) => r.id).join(", "))}</td></tr>`,
      )
      .join(
        "",
      )}</tbody></table><h2>Functionality disclosure</h2><p>Working browser functionality: search, validated forms, record updates, forecasts, workflow execution controls, call simulation states, local messages, invoice/payment/refund calculations, card-module controls, local persistence and file exports.</p><p>Production infrastructure required: authentication, tenant isolation, role enforcement, AI inference, real-time shared messaging, telephony, secure financial integrations and server-side audit logs. Physical card engineering and terminal compatibility remain unvalidated.</p>`,
  );
}
