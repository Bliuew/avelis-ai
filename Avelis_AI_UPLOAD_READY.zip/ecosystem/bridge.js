/* Version 1 browser integration port. This never contacts an external backend. */
(() => {
  "use strict";
  try {
    const raw = localStorage.getItem("avelis-ecosystem-v1");
    if (raw) {
      const s = JSON.parse(raw);
      if (s.version === 1 && Array.isArray(s.events))
        window.AvelisEcosystemAudit?.(s.events);
    }
    if (new URLSearchParams(location.search).get("ecosystem") === "advisor") {
      const raw = localStorage.getItem("avelis-ecosystem-advisor-v1");
      if (raw) window.AvelisAdvisorImport?.(JSON.parse(raw));
    }
  } catch (error) {
    console.warn("Ecosystem import unavailable:", error.message);
  }
})();
