// Optional DOM QA: install jsdom outside the repository; set JSDOM_PATH to its api.js.
import { readFile } from "node:fs/promises";
import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";
const { JSDOM } = await import(
  pathToFileURL(
    process.env.JSDOM_PATH ||
      "/tmp/avelis-dom-qa/node_modules/jsdom/lib/api.js",
  )
);
let passes = 0;
const pass = (n) => {
  console.log("PASS " + n);
  passes++;
};
const root = new URL("../../", import.meta.url);
const html = await readFile(new URL("index.html", root), "utf8");
const errors = [];
const original = new JSDOM(html, {
  url: "https://demo.example/avelis-ai/",
  runScripts: "outside-only",
  pretendToBeVisual: true,
});
const w = original.window;
w.HTMLElement.prototype.scrollIntoView = function () {};
w.URL.createObjectURL = () => "blob:test";
w.URL.revokeObjectURL = () => {};
w.HTMLAnchorElement.prototype.click = function () {};
w.addEventListener("error", (e) => errors.push(e.message));
for (const script of w.document.querySelectorAll("script:not([src])"))
  w.eval(script.textContent);
assert.deepEqual(errors, []);
assert.ok(w.AvelisDemoState());
pass("original scripts initialize without errors");
for (const side of w.document.querySelectorAll(".side")) {
  side.click();
  assert.ok(w.document.querySelector("#panel-content").textContent.trim());
}
pass("all original Command Centre panels render");
const originalPanel = (name) => {
  const side = w.document.querySelector(`.side[data-panel="${name}"]`);
  assert.ok(side, name);
  side.click();
};
const originalClick = (action) => {
  const b = w.document.querySelector(`[data-action="${action}"]`);
  assert.ok(b, action);
  b.click();
};
originalPanel("developer");
const integrationForm = w.document.querySelector("#integration-form");
assert.ok(integrationForm);
for (const [name, value] of Object.entries({
  integrationName: "Fictional Test Integration",
  integrationUrl: "https://integration.example/api",
  integrationPurpose: "Public demonstration test",
  integrationKind: "REST API",
}))
  integrationForm.elements[name].value = value;
integrationForm.dispatchEvent(
  new w.Event("submit", { bubbles: true, cancelable: true }),
);
const integration = w
  .AvelisDemoState()
  .integrations.find((i) => i.name === "Fictional Test Integration");
assert.ok(integration);
originalClick("review:" + integration.id);
const approval = w
  .AvelisDemoState()
  .approvals.find((a) => a.integrationId === integration.id);
assert.ok(approval);
originalClick("approve:" + approval.id);
assert.equal(approval.status, "Approved");
originalPanel("integrations");
originalClick("test:" + integration.id);
assert.ok(
  w.AvelisDemoState().tests.some((t) => t.integrationId === integration.id),
);
pass("original integration registration, governance approval and sandbox test");
originalPanel("incident");
const beforeIncidents = w.AvelisDemoState().incidents.length;
originalClick("generate-incident");
assert.equal(w.AvelisDemoState().incidents.length, beforeIncidents + 1);
const incident = w.AvelisDemoState().incidents[0];
originalClick("tab:response");
originalClick("ack:" + incident.id);
assert.equal(incident.status, "Acknowledged");
pass("original incident generation and acknowledgment");
originalPanel("specialists");
originalClick("specialist:0");
assert.match(
  w.document.querySelector("#chat-log").textContent,
  /planned capability/,
);
const chat = w.document.querySelector("#chat-form");
w.document.querySelector("#chat-input").value =
  "Summarize the local integrations";
chat.dispatchEvent(new w.Event("submit", { bubbles: true, cancelable: true }));
assert.match(
  w.document.querySelector("#chat-log").textContent,
  /Summarize the local integrations/,
);
pass("original specialists and rule-based assistant preview");
const plan = w.document.querySelector("#plan-select");
plan.value = "680";
plan.dispatchEvent(new w.Event("change", { bubbles: true }));
const seats = w.document.querySelector('[data-addon="seats"]');
seats.checked = true;
seats.dispatchEvent(new w.Event("change", { bubbles: true }));
assert.equal(w.document.querySelector("#total").textContent, "$715");
pass("original pricing calculator recomputes plan and add-on totals");
let oldExports = 0;
w.HTMLAnchorElement.prototype.click = function () {
  oldExports++;
};
originalPanel("audit");
originalClick("export-report");
originalClick("export-audit");
assert.equal(oldExports, 2);
pass("original integration and audit report exports");
w.confirm = () => true;
w.document.querySelector("#demo-reset").click();
assert.ok(
  !w.AvelisDemoState().integrations.some((i) => i.id === integration.id),
);
assert.equal(w.AvelisDemoState().integrations.length, 1);
pass("original demo reset preserves its own expected seed");

const parsed = w.AvelisAdvisorTest.parseCSV(
  "Transaction,Status,Amount CAD\nDEMO-1,Approved,500.00",
);
assert.equal(parsed.rows[0][2], "500.00");
assert.equal(w.AvelisAdvisorTest.computeStats([500]).sum, 500);
pass("Advisor parses supplied CSV and calculates CAD 500");
const upload = w.document.querySelector("#advisor-file");
Object.defineProperty(upload, "files", {
  value: [
    {
      name: "founder-sample.csv",
      size: 60,
      text: async () => "Transaction,Status,Amount CAD\nDEMO-1,Approved,500.00",
    },
  ],
});
upload.dispatchEvent(new w.Event("change"));
await new Promise((r) => setTimeout(r, 0));
assert.equal(w.document.querySelector("#advisor-metric").value, "Amount CAD");
assert.match(
  w.document.querySelector("#advisor-status").textContent,
  /Analysis complete/,
);
let originalDownloads = 0;
w.HTMLAnchorElement.prototype.click = function () {
  originalDownloads++;
};
w.document.querySelector("#advisor-export-csv").click();
w.document.querySelector("#advisor-export-html").click();
assert.equal(originalDownloads, 2);
pass("Advisor file input handler and both report downloads work");
w.AvelisAdvisorImport({
  version: "1.0",
  headers: [
    "date",
    "transaction",
    "status",
    "amount_cad",
    "fee_cad",
    "net_cad",
  ],
  rows: [["2026-11-17", "DEMO-1", "Approved", "500", "12.8", "487.2"]],
  source: "Test",
});
assert.equal(w.document.querySelector("#advisor-metric").value, "amount_cad");
assert.match(
  w.document.querySelector("#advisor-status").textContent,
  /Analysis complete/,
);
pass("connected dataset runs through original Advisor UI");
w.AvelisEcosystemAudit([
  { id: "TEST-EV", version: "1.0", type: "payment.approved" },
]);
const count = w.AvelisDemoState().audit.length;
w.AvelisEcosystemAudit([
  { id: "TEST-EV", version: "1.0", type: "payment.approved" },
]);
assert.equal(w.AvelisDemoState().audit.length, count);
pass("Avelis audit imports events idempotently");
w.eval(await readFile(new URL("ecosystem/appearance.js", root), "utf8"));
w.document.querySelector("#avelis-theme").click();
assert.ok(w.document.body.classList.contains("avelis-dark"));
w.document.querySelector("#avelis-theme").click();
assert.ok(!w.document.body.classList.contains("avelis-dark"));
pass("preserved Avelis page light/dark appearance control");
assert.equal(w.document.querySelector("#pilot-submit").disabled, true);
pass("private pilot configuration remains fail-closed");
const dom = new JSDOM(
  await readFile(new URL("ecosystem/index.html", root), "utf8"),
  {
    url: "https://demo.example/avelis-ai/ecosystem/index.html#investor",
    pretendToBeVisual: true,
  },
);
const d = dom.window;
for (const k of [
  "window",
  "document",
  "location",
  "localStorage",
  "FormData",
  "CustomEvent",
])
  globalThis[k] = k === "window" ? d : d[k];
d.HTMLElement.prototype.scrollIntoView = function () {};
let downloads = [];
d.HTMLAnchorElement.prototype.click = function () {
  downloads.push(this.download);
};
const { store } = await import("../app.js");
const q = (s) => d.document.querySelector(s);
const tick = () => new Promise((r) => setTimeout(r, 0));
async function route(r) {
  d.location.hash = r;
  await tick();
}
async function submit(selector, values = {}) {
  const f = q(selector);
  assert.ok(f, selector);
  for (const [k, v] of Object.entries(values)) f.elements[k].value = v;
  f.dispatchEvent(new d.Event("submit", { bubbles: true, cancelable: true }));
  await tick();
}
function click(a, key) {
  const b = [...d.document.querySelectorAll(`[data-action="${a}"]`)].find(
    (b) => !key || b.dataset.key === key,
  );
  assert.ok(b, a);
  b.click();
}
for (const r of [
  "discover",
  "relations",
  "connect",
  "link",
  "flow",
  "intelligence",
  "coach",
  "teams",
  "insights",
  "commerce",
  "merchant",
  "cards",
  "rewards",
  "security",
  "investor",
]) {
  await route(r);
  assert.ok(q("h1"), r);
}
pass("all 15 application routes render");
await route("discover");
await submit("#discover-search", { search: "Cedar" });
assert.equal(
  d.document.querySelectorAll('[data-action="add-prospect"]').length,
  1,
);
click("add-prospect", "P-1");
assert.equal(store.state.ama.contacts.length, 1);
pass("Discover search and CRM add operate through UI");
await route("relations");
await submit("#contact-form", {
  name: "<img src=x onerror=alert(1)>",
  company: "Fictional Test",
  email: "x@test.example",
  role: "Director",
});
assert.equal(d.document.querySelectorAll("#content img").length, 0);
const c = store.state.ama.contacts[0];
click("edit-contact", c.id);
await submit("#contact-form", { name: "Alex Updated" });
assert.equal(store.state.ama.contacts[0].name, "Alex Updated");
await submit("#opportunity-form", {
  name: "Demo sale",
  contact: c.id,
  value: "50000",
  probability: "60",
  stage: "Proposal",
});
assert.match(q("#content").textContent, /300.00/);
pass("contact creation, safe rendering, editing and forecast UI");
await route("connect");
await submit("#call-form", { contact: c.id });
assert.equal(store.state.ama.activeCall.status, "Connecting");
click("call-active");
click("call-hold");
await submit("#participant-form", { name: "Jordan Example" });
assert.equal(store.state.ama.activeCall.participants.length, 2);
click("call-mute");
click("call-end");
assert.equal(store.state.ama.calls.length, 1);
pass("call controls, conference participant and transcript UI");
await route("coach");
click("coach-reviewed");
assert.ok(store.state.progress.includes("coach"));
pass("transcript evidence and review action");
await route("link");
await submit("#message-form", {
  body: "Please review the customer quotation.",
});
const message = store.state.ama.messages.at(-1);
await submit(`[data-thread="${message.id}"]`, { body: "Reviewing now." });
click("message-task", message.id);
assert.equal(store.state.ama.tasks.at(-1).message, message.id);
await submit("#channel-form", { name: "Customer project", kind: "Group" });
assert.equal(store.state.ama.channels.at(-1).name, "Group · Customer project");
pass("local messages, threads, channel creation and conversion to tasks");
await route("flow");
await submit("#workflow-form", {
  contact: c.id,
  steps: "Call: Introduce offer\nEmail: Draft follow-up",
});
let flow = store.state.ama.workflows.at(-1);
click("flow-execute", flow.id);
click("flow-pause", flow.id);
assert.equal(flow.status, "Paused");
click("flow-resume", flow.id);
click("flow-execute", flow.id);
assert.equal(flow.status, "Completed");
pass("workflow execution, pause/resume and task creation");
await route("relations");
const opp = store.state.ama.opportunities[0];
click("edit-opportunity", opp.id);
await submit("#opportunity-form", { stage: "Won" });
assert.equal(store.state.ama.opportunities[0].stage, "Won");
pass("opportunity closes through configurable pipeline UI");
await route("commerce");
q("[name=quantity]").value = "2";
q("[name=quantity]").dispatchEvent(new d.Event("input", { bubbles: true }));
assert.match(q("#invoice-preview").textContent, /1,000.00/);
q("[name=unit]").value = "25000";
await submit("#invoice-form", { contact: c.id, opportunity: opp.id });
assert.equal(store.state.ama.invoices[0].lines[0].quantity, 2);
pass("invoice live recalculation and connected save");
await route("merchant");
click("toggle-sharim");
const invoice = store.state.ama.invoices[0];
await submit("#payment-form", {
  invoice: invoice.id,
  key: "UI-DEMO-1",
  status: "Approved",
});
assert.equal(invoice.paid, 50000);
const tx = store.state.sharim.transactions[0];
await submit("#payment-form", {
  invoice: invoice.id,
  key: "UI-DEMO-1",
  status: "Approved",
});
assert.equal(store.state.sharim.transactions.length, 1);
click("refund", tx.id);
assert.equal(invoice.paid, 0);
assert.equal(tx.status, "Refunded");
pass("payment UI updates invoice, blocks duplicates and supports refunds");
click("toggle-sharim");
await route("relations");
assert.ok(q("#contact-form"));
pass("Amā continues after Sharim disconnect");
await route("cards");
assert.equal(d.document.querySelectorAll(".module-art").length, 4);
assert.ok(q(".assembly img"));
click("cards-detach");
assert.ok(store.state.sharim.modules.every((m) => !m.attached));
click("cards-assemble");
click("module-freeze", "MOD-1");
assert.equal(store.state.sharim.modules[0].frozen, true);
pass("Card Studio assembly, detachment and freeze UI");
await route("commerce");
click("invoice-download", invoice.id);
await route("merchant");
click("receipt", tx.id);
click("transaction-export");
await route("insights");
click("insights-export");
await route("discover");
click("prospect-export");
await route("investor");
click("report");
click("report-html");
assert.equal(downloads.length, 7);
assert.ok(downloads.every(Boolean));
pass("all seven new report/export handlers initiate named downloads");
await route("investor");
assert.ok(store.state.progress.includes("payment"));
assert.equal(
  JSON.parse(d.localStorage.getItem("avelis-ecosystem-v1")).ama.invoices.length,
  1,
);
click("reset");
click("confirm-reset");
assert.equal(store.state.ama.contacts.length, 0);
pass("cross-application progress, persistence and explicit ecosystem reset");
// Exercise secondary features and negative controls through the actual DOM event handlers.
await route("relations");
await submit("#contact-form", {
  name: "Queue Demo",
  company: "Fictional Queue Co",
  email: "queue@demo.example",
});
const queued = store.state.ama.contacts[0];
await route("connect");
await submit("#queue-form", { queue: "Q-1", contact: queued.id });
const item = store.state.ama.queues[0].items[0];
click("queue-answer", item.id);
assert.equal(store.state.ama.activeCall.direction, "Inbound");
assert.equal(store.state.ama.queues[0].items.length, 0);
click("call-active");
click("call-end");
pass("inbound queue create, answer and completed call");
await route("teams");
await submit("#task-form", {
  title: "Assign this follow-up",
  contact: queued.id,
});
const assigned = store.state.ama.tasks.at(-1);
click("edit-task", assigned.id);
await submit("#task-form", {
  assignee: "Taylor Demo",
  title: "Reassigned follow-up",
  due: "2026-12-01",
});
assert.equal(assigned.assignee, "Taylor Demo");
assert.equal(assigned.title, "Reassigned follow-up");
pass("task assignment editing and follow-up due dates");
await route("intelligence");
await submit("#intelligence-form", {
  language: "Français",
  query: "prévision pipeline",
});
assert.match(q("#content").textContent, /Prévision pondérée/);
await submit("#document-form", {
  document: "Approval required.\nFollow-up deadline: Friday.",
});
assert.match(q("#document-result").textContent, /Line 1/);
assert.match(q("#document-result").textContent, /Line 2/);
pass("multilingual deterministic forecast and document evidence lines");
await route("insights");
await submit("#range-form", {
  from: "2099-01-01",
  to: "2099-12-31",
  stage: "Won",
});
assert.match(q("#content").textContent, /0.0%/);
click("clear-range");
assert.equal(q("[name=from]").value, "");
pass("dashboard filters apply and clear consistently");
await route("link");
const attachInput = q("[name=attachment]");
Object.defineProperty(attachInput, "files", {
  configurable: true,
  value: [
    {
      name: "fictional-note.txt",
      size: 8,
      type: "text/plain",
      arrayBuffer: async () => new TextEncoder().encode("fiction").buffer,
    },
  ],
});
await submit("#message-form", { body: "Attached fictional note." });
const withFile = store.state.ama.messages.at(-1);
assert.equal(withFile.attachment.name, "fictional-note.txt");
click("attachment-download", withFile.id);
assert.equal(downloads.at(-1), "fictional-note.txt");
pass("local attachment content handling and download");
let importedFile = q("#prospect-import");
await route("discover");
importedFile = q("#prospect-import");
Object.defineProperty(importedFile, "files", {
  value: [
    {
      name: "approved.csv",
      size: 200,
      text: async () =>
        "company,name,industry,location,size,role,email\nFictional Import,Import Demo,Design,Toronto,30,Director,import@demo.example",
    },
  ],
});
importedFile.dispatchEvent(new d.Event("change", { bubbles: true }));
await tick();
q("#import-confirm [name=fictional]").checked = true;
await submit("#import-confirm");
assert.equal(store.state.ama.prospects.at(-1).company, "Fictional Import");
pass("approved CSV dataset validation and explicit fictional-record import");
await route("commerce");
await submit("#invoice-form", { contact: queued.id });
const commercial = store.state.ama.invoices.at(-1);
click("quote", commercial.id);
const quote = store.state.ama.quotes.at(-1);
click("quote-download", quote.id);
click("quote-accept", quote.id);
const order = store.state.ama.orders.at(-1);
assert.equal(quote.status, "Accepted");
click("order-fulfill", order.id);
assert.equal(order.status, "Fulfilled");
pass("quotation snapshot download, acceptance and order fulfillment");
await route("rewards");
await submit("#benefit-form", {
  merchant: "Fictional Loyalty Merchant",
  description: "Demonstration bonus points",
  points: "3",
});
assert.equal(store.state.sharim.benefit, 3);
assert.equal(store.state.sharim.merchant, "Fictional Loyalty Merchant");
pass("merchant rewards benefit configuration");
await route("relations");
const accountProfile = store.state.ama.accounts.find(
  (a) => a.id === queued.account,
);
click("edit-account", accountProfile.id);
await submit("#account-form", {
  name: "Fictional Account Updated",
  industry: "Design",
  location: "Toronto",
  size: "50",
});
assert.equal(accountProfile.size, 50);
assert.equal(
  store.state.ama.contacts.find((c) => c.id === queued.id).company,
  "Fictional Account Updated",
);
pass("account profile editing synchronizes linked customer records");
console.log(
  `DOM QA: ${passes} passed; 0 failed. This does not verify visual layout or browser compatibility.`,
);
dom.window.close();
original.window.close();
