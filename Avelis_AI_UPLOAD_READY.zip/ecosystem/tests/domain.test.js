import test from "node:test";
import assert from "node:assert/strict";
import { seed, Store, KEY, parseCSV, csv } from "../core/store.js";
import * as A from "../ama/domain.js";
import * as S from "../sharim/domain.js";
import { advisorDataset, BackendAdapter } from "../core/adapters.js";
const fixture = () => {
  const s = seed(),
    c = A.addProspect(s, "P-1"),
    o = A.opportunity(s, {
      name: "Fictional proposal",
      contact: c.id,
      value: 50000,
      probability: 60,
      stage: "Proposal",
    }),
    i = A.invoice(s, {
      contact: c.id,
      opportunity: o.id,
      lines: [{ description: "Service", quantity: 2, unit: 25000 }],
    });
  return { s, c, o, i };
};
test("contacts create, edit, archive and deduplicate prospects", () => {
  const { s, c } = fixture();
  assert.equal(A.addProspect(s, "P-1").id, c.id);
  A.contact(s, { ...c, name: "Updated Demo" });
  assert.equal(s.ama.contacts.length, 1);
  assert.equal(s.ama.contacts[0].name, "Updated Demo");
  c.archived = true;
  assert.equal(A.addProspect(s, "P-1").archived, false);
  assert.throws(() =>
    A.contact(s, { name: "Real", company: "Test", email: "x@real.com" }),
  );
});
test("opportunity forecasts recalculate on edits and closing", () => {
  const { s, c, o } = fixture();
  assert.equal(A.metrics(s).weighted, 30000);
  A.opportunity(s, { ...o, contact: c.id, probability: 25, value: 100000 });
  assert.equal(A.metrics(s).weighted, 25000);
  A.opportunity(s, { ...o, stage: "Won" });
  assert.equal(A.metrics(s).weighted, 0);
  assert.equal(A.metrics(s).conversion, 100);
});
test("call transitions include participant, mute, hold, transfer, transcript", () => {
  const { s, c } = fixture();
  A.call(s, "start", { contact: c.id });
  assert.equal(s.ama.activeCall.status, "Connecting");
  assert.throws(() => A.call(s, "participant", { name: "Jordan Example" }));
  A.call(s, "active");
  A.call(s, "hold");
  assert.equal(s.ama.activeCall.status, "Hold");
  A.call(s, "participant", { name: "Jordan Example" });
  A.call(s, "mute");
  A.call(s, "transfer", { name: "Taylor Demo" });
  assert.equal(s.ama.activeCall.participants.length, 3);
  A.call(s, "end");
  assert.equal(s.ama.activeCall, null);
  assert.equal(s.ama.calls[0].status, "Completed");
  assert.equal(A.coach(s.ama.calls[0], s.ama.criteria).score, 100);
});
test("message tasks retain message, customer and opportunity links", () => {
  const { s, c, o } = fixture();
  const t = A.task(s, {
    title: "Follow up",
    message: "M-1",
    contact: c.id,
    opportunity: o.id,
    approval: true,
  });
  assert.equal(t.message, "M-1");
  assert.equal(t.status, "Pending approval");
  assert.equal(A.metrics(s).tasks, 1);
});
test("workflow creates tasks, pauses, resumes and gates approval", () => {
  const { s, c } = fixture();
  const w = A.workflow(s, { name: "Outreach", contact: c.id });
  A.runWorkflow(s, w, "execute");
  assert.equal(w.status, "Running");
  A.runWorkflow(s, w, "pause");
  assert.throws(() => A.runWorkflow(s, w, "execute"));
  A.runWorkflow(s, w, "resume");
  A.runWorkflow(s, w, "execute");
  A.runWorkflow(s, w, "execute");
  A.runWorkflow(s, w, "execute");
  assert.equal(w.status, "Waiting approval");
  assert.throws(() => A.runWorkflow(s, w, "resume"));
  s.ama.tasks.find((t) => t.id === w.approvalTask).status = "Approved";
  A.runWorkflow(s, w, "resume");
  assert.equal(w.status, "Completed");
  assert.throws(() => A.runWorkflow(s, w, "execute"));
});
test("workflow conditional cancellation and scheduled execution", () => {
  const { s } = fixture();
  const c = A.addProspect(s, "P-2"),
    w = A.workflow(s, {
      name: "No email",
      contact: c.id,
      steps: [{ kind: "Condition", title: "Has email" }],
    });
  A.runWorkflow(s, w, "execute");
  assert.equal(w.status, "Cancelled");
  const future = A.workflow(s, {
    name: "Future",
    contact: c.id,
    scheduled: "2099-01-01",
  });
  assert.throws(() => A.runWorkflow(s, future, "execute"));
});
test("invoice quantities and prices recalculate and reject invalid cents", () => {
  const { s, c, i } = fixture();
  assert.equal(A.total(i), 50000);
  A.invoice(s, {
    id: i.id,
    contact: c.id,
    lines: [{ description: "Revised", quantity: 3, unit: 11001 }],
  });
  assert.equal(A.total(i), 33003);
  assert.throws(() =>
    A.invoice(s, {
      contact: c.id,
      lines: [{ description: "Invalid", quantity: 1, unit: 1.1 }],
    }),
  );
});
test("approved and declined payments, duplicate prevention, refunds, settlements", () => {
  const { s, i } = fixture();
  const d = {
    invoice: i.id,
    key: "DEMO-1",
    module: "MOD-1",
    status: "Approved",
  };
  assert.throws(() => S.payment(s, d));
  s.sharim.connected = true;
  const t = S.payment(s, d);
  assert.equal(i.paid, 50000);
  assert.equal(i.status, "Paid");
  assert.equal(t.fee, 1280);
  assert.equal(S.settlement(s), 48720);
  assert.equal(S.payment(s, d).id, t.id);
  assert.equal(s.sharim.transactions.length, 1);
  assert.throws(() => S.payment(s, { ...d, key: "another" }));
  assert.throws(() =>
    A.invoice(s, {
      id: i.id,
      contact: i.contact,
      lines: [{ description: "Change", quantity: 1, unit: 100 }],
    }),
  );
  S.refund(s, t.id);
  assert.equal(i.paid, 0);
  assert.equal(i.status, "Refunded");
  assert.equal(t.points, 0);
  assert.equal(S.settlement(s), 0);
  assert.equal(s.sharim.modules[0].spent, 0);
  assert.throws(() => S.refund(s, t.id));
  const declined = S.payment(s, { ...d, key: "decline", status: "Declined" });
  assert.equal(declined.status, "Declined");
  assert.equal(i.paid, 0);
  assert.equal(declined.fee, 0);
});
test("frozen modules, limits and permissions prevent approval", () => {
  const { s, i } = fixture();
  s.sharim.connected = true;
  const d = { invoice: i.id, key: "P", module: "MOD-1", status: "Approved" };
  s.sharim.modules[0].frozen = true;
  assert.throws(() => S.payment(s, d));
  s.sharim.modules[0].frozen = false;
  s.sharim.modules[0].limit = 40000;
  assert.throws(() => S.payment(s, d));
  s.sharim.permissions = false;
  assert.throws(() => S.payment(s, d));
  assert.equal(i.paid, 0);
});
test("disconnect preserves independent Amā and card assembly states", () => {
  const { s, c, i } = fixture();
  s.sharim.connected = false;
  const o = A.opportunity(s, {
    contact: c.id,
    name: "Independent",
    value: 10000,
    probability: 10,
    stage: "Qualified",
  });
  assert.ok(o.id);
  assert.throws(() =>
    S.payment(s, {
      invoice: i.id,
      key: "x",
      module: "MOD-1",
      status: "Approved",
    }),
  );
  s.sharim.modules[0].attached = false;
  assert.equal(s.sharim.modules.filter((m) => m.attached).length, 3);
});
test("Advisor dataset uses actual transaction cents and refund reversals", () => {
  const { s, i } = fixture();
  s.sharim.connected = true;
  const t = S.payment(s, {
    invoice: i.id,
    key: "D",
    module: "MOD-1",
    status: "Approved",
  });
  let d = advisorDataset(s);
  assert.equal(d.rows[0][3], "500");
  assert.equal(
    d.rows.reduce((n, r) => n + Number(r[5]), 0),
    487.2,
  );
  S.refund(s, t.id);
  assert.equal(advisorDataset(s).rows[0][3], "0");
});
test("persistence, isolated reset, failure rollback and storage errors", () => {
  const data = new Map([["avelis-connected-demo-v1", "original"]]);
  const storage = {
    getItem: (k) => data.get(k),
    setItem: (k, v) => data.set(k, v),
  };
  const store = new Store(storage);
  store.change("contact.created", (s) => A.addProspect(s, "P-1"));
  assert.equal(new Store(storage).state.ama.contacts.length, 1);
  const before = JSON.stringify(store.state);
  assert.throws(() =>
    store.change("bad", (s) => {
      s.ama.contacts = [];
      throw Error("invalid");
    }),
  );
  assert.equal(JSON.stringify(store.state), before);
  store.reset();
  assert.equal(store.state.ama.contacts.length, 0);
  assert.equal(data.get("avelis-connected-demo-v1"), "original");
  assert.ok(data.has(KEY));
  store.storage.setItem = () => {
    throw Error("Quota");
  };
  store.save();
  assert.match(store.warning, /memory only/);
});
test("CSV quoted fields, formulas and malformed quotes", () => {
  assert.deepEqual(parseCSV('company,name\r\n"Cedar, Finch","Alex ""Demo"""'), [
    ["company", "name"],
    ["Cedar, Finch", 'Alex "Demo"'],
  ]);
  assert.match(csv([["=CMD()"]]), /'=CMD/);
  assert.throws(() => parseCSV('"unclosed'));
});
test("deterministic queries reference records; backend fails closed", async () => {
  const { s, o } = fixture();
  const r = A.intelligence(s, "pipeline forecast");
  assert.ok(r.refs.includes(o.id));
  assert.match(r.answer, /300.00/);
  await assert.rejects(
    new BackendAdapter().request("ai", {}),
    /server deployment/,
  );
});

// Preservation checks use a small public baseline captured from main f097148.
import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
const project = new URL("../../", import.meta.url),
  baseline = JSON.parse(
    readFileSync(
      new URL("preservation-baseline.json", import.meta.url),
      "utf8",
    ),
  ),
  source = readFileSync(new URL("index.html", project), "utf8");
test("all original section and control IDs remain present", () => {
  const ids = [...source.matchAll(/\bid="([^"]+)"/g)].map((m) => m[1]);
  for (const id of baseline.ids) assert.ok(ids.includes(id), id);
});
test("original Avelis and Ditheka image tags remain byte-identical", () => {
  const images = [...source.matchAll(/<img[^>]*>/g)].map((m) =>
    createHash("sha256").update(m[0]).digest("hex"),
  );
  for (const hash of baseline.logos) assert.ok(images.includes(hash));
});
test("original source archives remain byte-identical", () => {
  for (const [name, hash] of Object.entries(baseline.archives))
    assert.equal(
      createHash("sha256")
        .update(readFileSync(new URL(name, project)))
        .digest("hex"),
      hash,
    );
});
test("original pilot backend placeholders and storage key remain unchanged", () => {
  assert.ok(source.includes("const STORE='avelis-connected-demo-v1'"));
  assert.ok(source.includes("const API_BASE='__PILOT_API_BASE__'"));
  assert.ok(source.includes("const CONTACT_EMAIL='__PRIVACY_CONTACT_EMAIL__'"));
});

import { snapshot } from "../ama/insights.js";
import {
  inspectDocument,
  attachment,
  attachmentBytes,
} from "../ama/documents.js";
import { ServerAdapter } from "../core/adapters.js";
import { invoiceHTML, receiptHTML, investorHTML } from "../core/reports.js";
test("filtered dashboards and exports share calculated record subsets", () => {
  const { s, o } = fixture();
  let view = snapshot(s, { stage: "Proposal" });
  assert.equal(view.metrics.weighted, 30000);
  assert.equal(
    view.charts.pipeline.find(([name]) => name === "Proposal")[1],
    50000,
  );
  view = snapshot(s, { stage: "Won" });
  assert.equal(view.metrics.weighted, 0);
  assert.equal(view.metrics.invoiced, 0);
  view = snapshot(s, { from: "2099-01-01" });
  assert.equal(view.metrics.invoiced, 0);
  assert.equal(view.metrics.calls, 0);
});
test("payment idempotency keys reject a changed request payload", () => {
  const { s, i } = fixture();
  s.sharim.connected = true;
  const d = {
    invoice: i.id,
    key: "BOUND-KEY",
    status: "Approved",
    module: "MOD-1",
  };
  S.payment(s, d);
  assert.throws(
    () => S.payment(s, { ...d, status: "Declined" }),
    /different request/,
  );
  assert.equal(s.sharim.transactions.length, 1);
});
test("connected-card mode enforces assembly, individual mode permits detached module", () => {
  const { s, i } = fixture();
  s.sharim.connected = true;
  s.sharim.modules[0].attached = false;
  const d = {
    invoice: i.id,
    key: "MODULE",
    status: "Approved",
    module: "MOD-1",
  };
  assert.throws(() => S.payment(s, d), /Assemble/);
  s.sharim.mode = "individual";
  S.payment(s, d);
  assert.equal(i.status, "Paid");
});
test("transaction alerts are generated only when enabled and refunds reverse points", () => {
  const { s, i } = fixture();
  s.sharim.connected = true;
  const t = S.payment(s, {
    invoice: i.id,
    key: "ALERT",
    status: "Approved",
    module: "MOD-1",
  });
  assert.equal(s.sharim.notifications.length, 1);
  s.sharim.alerts = false;
  S.refund(s, t.id);
  assert.equal(s.sharim.notifications.length, 1);
  assert.equal(t.originalFee, 1280);
});
test("document inspection returns verbatim line evidence without model inference", () => {
  const x = inspectDocument(
    "Approval on Monday.\nFollow-up cost is fictional.",
  );
  assert.equal(x.lines, 2);
  assert.equal(
    x.evidence.find((x) => x.term === "approval").matches[0].line,
    1,
  );
  assert.equal(x.evidence.find((x) => x.term === "cost").matches[0].line, 2);
  assert.throws(() => inspectDocument(""));
});
test("attachments round-trip bytes and reject oversized or executable files", async () => {
  const bytes = new TextEncoder().encode("Fictional attachment");
  const file = await attachment({
    name: "example.txt",
    size: bytes.length,
    type: "text/plain",
    arrayBuffer: async () => bytes.buffer,
  });
  assert.deepEqual(attachmentBytes(file), bytes);
  await assert.rejects(
    attachment({ name: "executable.html", size: 10 }),
    /Supported/,
  );
  await assert.rejects(
    attachment({ name: "large.pdf", size: 500001 }),
    /500 KB/,
  );
});
test("downloadable HTML reports escape all record text and show actual totals", () => {
  const { s, c, i } = fixture();
  c.company = "<script>alert(1)</script>";
  const html = invoiceHTML(s, i, A.total(i));
  assert.ok(!html.includes("<script>"));
  assert.ok(html.includes("&lt;script&gt;"));
  assert.match(html, /500.00/);
  s.sharim.connected = true;
  const tx = S.payment(s, {
    invoice: i.id,
    key: "HTML",
    module: "MOD-1",
    status: "Approved",
  });
  assert.match(receiptHTML(s, tx), /487.20/);
  assert.match(investorHTML(s, A.metrics(s), []), /1 contacts/);
});
test("configured server adapter fails closed and never accepts client API secrets", async () => {
  const disabled = new ServerAdapter();
  await assert.rejects(disabled.request("ai", {}), /not configured/);
  assert.throws(
    () => new ServerAdapter({ baseUrl: "http://backend.example" }),
    /HTTPS/,
  );
  assert.throws(
    () => new ServerAdapter({ baseUrl: "https://key@backend.example" }),
    /credentials/,
  );
  let request;
  const adapter = new ServerAdapter({
    enabled: true,
    baseUrl: "https://backend.example",
    csrfToken: "public-session-csrf",
    fetchImpl: async (url, options) => {
      request = { url, options };
      return {
        ok: true,
        headers: { get: () => "application/json" },
        json: async () => ({
          version: "1.0",
          model: "authorized-server-model",
          answer: "Test backend response",
          evidence: [],
        }),
      };
    },
  });
  await adapter.request("ai", { query: "forecast" });
  assert.equal(request.options.credentials, "include");
  assert.equal(request.url, "https://backend.example/api/v1/ai");
  assert.ok(!("Authorization" in request.options.headers));
});

test("all static application scripts, styles and original logo resources exist", () => {
  for (const rel of ["index.html", "ecosystem/index.html"]) {
    const html = readFileSync(new URL(rel, project), "utf8");
    for (const match of html.matchAll(/(?:src|href)="([^"#]+)"/g)) {
      const path = match[1].split("#")[0].split("?")[0];
      if (!path || /^(?:[a-z]+:|\/\/)/i.test(path)) continue;
      assert.ok(
        readFileSync(new URL(path, new URL(rel, project))).length > 0,
        path,
      );
    }
  }
});
test("packaged card artwork matches the founder-approved crop manifest", () => {
  const manifest = JSON.parse(
    readFileSync(
      new URL("ecosystem/assets/ARTWORK-PROVENANCE.json", project),
      "utf8",
    ),
  );
  for (const [name, expected] of Object.entries(manifest.output_sha256)) {
    const bytes = readFileSync(new URL("ecosystem/assets/" + name, project));
    assert.equal(createHash("sha256").update(bytes).digest("hex"), expected);
    assert.equal(bytes.subarray(1, 4).toString(), "PNG");
  }
  assert.equal(Object.keys(manifest.crops).length, 5);
});
test("original entry point backup is byte-identical and the supplied CSV is included", () => {
  assert.equal(
    createHash("sha256")
      .update(
        readFileSync(new URL("backups/original-main-index.html", project)),
      )
      .digest("hex"),
    "15f94c907358c87d05bcca7f4a04fcb725ed20ffc2694b689b30492717e60537",
  );
  assert.match(
    readFileSync(
      new URL("samples/Founder_Transaction_Sample.csv", project),
      "utf8",
    ),
    /DEMO-1,Approved,500.00/,
  );
});

test("account profiles group contacts and preserve stable relationships on rename", () => {
  const { s, c } = fixture();
  const profile = s.ama.accounts.find((a) => a.id === c.account);
  assert.ok(profile);
  assert.equal(profile.name, c.company);
  A.contact(s, {
    name: "Second Demo",
    company: c.company,
    email: "second@cedar.example",
  });
  assert.equal(s.ama.accounts.length, 1);
  A.account(s, {
    accountId: profile.id,
    name: "Renamed Fictional Studio",
    industry: "Design",
    location: "Toronto",
    size: 30,
  });
  assert.ok(
    s.ama.contacts.every((c) => c.company === "Renamed Fictional Studio"),
  );
  assert.ok(s.ama.contacts.every((c) => c.account === profile.id));
});
test("persisted older contacts migrate deterministically to account profiles", () => {
  const { s, c } = fixture();
  delete s.ama.accounts;
  delete c.account;
  const storage = { getItem: () => JSON.stringify(s), setItem: () => {} };
  const first = new Store(storage),
    second = new Store(storage);
  assert.equal(
    first.state.ama.contacts[0].account,
    second.state.ama.contacts[0].account,
  );
  assert.equal(first.state.ama.accounts.length, 1);
});
