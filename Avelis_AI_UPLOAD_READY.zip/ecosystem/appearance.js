/* Optional appearance control for the preserved Avelis website. */
(() => {
  "use strict";
  const nav = document.querySelector("#navlinks");
  if (!nav) return;
  const key = "avelis-site-theme-v1";
  let theme = "light";
  try {
    theme = localStorage.getItem(key) || "light";
  } catch {}
  const button = document.createElement("button");
  button.id = "avelis-theme";
  button.type = "button";
  button.className = "avelis-theme-button";
  nav.append(button);
  function apply() {
    document.body.classList.toggle("avelis-dark", theme === "dark");
    button.textContent = theme === "dark" ? "Light theme" : "Dark theme";
    button.setAttribute("aria-pressed", String(theme === "dark"));
  }
  button.addEventListener("click", () => {
    theme = theme === "dark" ? "light" : "dark";
    try {
      localStorage.setItem(key, theme);
    } catch {}
    apply();
  });
  apply();
})();
