import {
  Store,
  id,
  date,
  text,
  integer,
  csv,
  parseCSV,
  download,
} from "./core/store.js";
import * as A from "./ama/domain.js";
import * as S from "./sharim/domain.js";
import { advisorDataset } from "./core/adapters.js";
import { snapshot } from "./ama/insights.js";
import { invoiceHTML, receiptHTML, investorHTML } from "./core/reports.js";
import {
  inspectDocument,
  attachment,
  attachmentBytes,
} from "./ama/documents.js";
let browserStorage;
try {
  browserStorage = localStorage;
} catch {
  browserStorage = null;
}
export const store = new Store(browserStorage);
window.Ecosystem = { store, A, S };
const $ = (s) => document.querySelector(s),
  esc = (v) =>
    String(v ?? "").replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[c],
    ),
  money = (n) =>
    new Intl.NumberFormat("en-CA", {
      style: "currency",
      currency: "CAD",
    }).format(n / 100);
const button = (label, action, key = "", cls = "") =>
  `<button class="${cls}" data-action="${action}" data-key="${esc(key)}">${label}</button>`;
const field = (label, name, value = "", type = "text", extra = "") =>
  `<label>${label}<input name="${name}" type="${type}" value="${esc(value)}" ${extra}></label>`;
const select = (label, name, options, value = "") =>
  `<label>${label}<select name="${name}">${options
    .map((o) => {
      const [v, l] = Array.isArray(o) ? o : [o, o];
      return `<option value="${esc(v)}" ${v === value ? "selected" : ""}>${esc(l)}</option>`;
    })
    .join("")}</select></label>`;
const empty = (msg) => `<div class="empty">${msg}</div>`;
const contacts = () =>
  store.state.ama.contacts
    .filter((c) => !c.archived)
    .map((c) => [c.id, `${c.name} · ${c.company}`]);
const cname = (id) =>
  store.state.ama.contacts.find((c) => c.id === id)?.company || "No customer";
const card = (title, body) =>
  `<section class="card"><h2>${title}</h2>${body}</section>`;
let route = "",
  channel = "CH-1",
  workspace = "Demo company",
  editingContact = null,
  editingOpportunity = null,
  editingInvoice = null,
  editingTask = null,
  editingAccount = null,
  language = "English",
  chartStage = "",
  chartSource = "",
  pipelineSearch = "",
  query = "",
  answer = null,
  filters = {},
  chartFrom = "",
  chartTo = "";
const pages = [
  ["investor", "Experience Centre"],
  ["discover", "Discover"],
  ["relations", "Relations"],
  ["connect", "Connect"],
  ["link", "Link"],
  ["flow", "Flow"],
  ["intelligence", "Intelligence"],
  ["coach", "Coach"],
  ["teams", "Teams"],
  ["insights", "Insights"],
  ["commerce", "Commerce"],
  ["merchant", "Merchant sandbox"],
  ["cards", "Card Studio"],
  ["rewards", "Rewards"],
  ["security", "Security"],
];
const steps = [
  ["discover", "Open Amā Discover", "discover"],
  ["discover", "Search fictional prospects", "searched"],
  ["discover", "Save a prospect to CRM", "contact"],
  ["relations", "Create an opportunity", "opportunity"],
  ["flow", "Build an outreach flow", "flow"],
  ["connect", "Initiate a simulated call", "call"],
  ["connect", "Add a colleague", "participant"],
  ["coach", "Review transcript and coaching", "coach"],
  ["link", "Create a message-linked task or approval", "task"],
  ["relations", "Close an opportunity as Won", "won"],
  ["commerce", "Create an invoice", "invoice"],
  ["merchant", "Connect Sharim sandbox", "connected"],
  ["merchant", "Approve a fictional payment", "payment"],
  ["insights", "Review invoice and customer activity", "insights"],
  ["merchant", "Inspect transaction records", "merchant"],
  ["insights", "Send the dataset to Advisor™", "advisor"],
  ["security", "Review integration and governance events", "audit"],
  ["investor", "Download demonstration report", "report"],
];
let noticeTimer;
function notice(msg) {
  $("#notice").textContent = msg;
  $("#notice").style.display = "block";
  clearTimeout(noticeTimer);
  noticeTimer = setTimeout(() => ($("#notice").style.display = "none"), 6000);
}
function mark(s, k) {
  if (!s.progress.includes(k)) s.progress.push(k);
}
function change(type, fn, detail = {}) {
  return store.change(
    type,
    (s) => {
      const result = fn(s);
      return result;
    },
    detail,
  );
}
function move(r) {
  location.hash = r;
}
function report() {
  return {
    disclosure:
      "Fictional browser-local demonstration. No live AI, payments, telephony or multi-user messaging.",
    generated: date(),
    metrics: A.metrics(store.state),
    ...store.state,
  };
}
function render() {
  const focused = document.activeElement,
    focusAction = focused?.dataset?.action,
    focusKey = focused?.dataset?.key,
    focusedId = focused?.id,
    selection = focused?.selectionStart;
  route = location.hash.slice(1) || "investor";
  if (!pages.some(([p]) => p === route)) route = "investor";
  if (route === "discover" && !store.state.progress.includes("discover"))
    change("ama.discover.opened", (s) => mark(s, "discover"));
  const s = store.state;
  document.body.className =
    (s.theme === "dark" ? "dark " : "") +
    (["merchant", "cards", "rewards", "security"].includes(route)
      ? "sharim"
      : "");
  $("#theme").textContent = s.theme === "dark" ? "Light theme" : "Dark theme";
  $("#sidebar").innerHTML =
    `<img src="assets/${["merchant", "cards", "rewards", "security"].includes(route) ? "sharim.jpg" : "ama.jpg"}" alt="Original ${["merchant", "cards", "rewards", "security"].includes(route) ? "Sharim" : "Amā"} logo"><div class="label">Investor experience</div>${pages.map(([p, n], i) => `${i === 1 ? '<div class="label">Amā · Exploring Both Worlds.</div>' : ""}${i === 11 ? '<div class="label">Sharim · Under Maarah</div>' : ""}<a class="${route === p ? "active" : ""}" href="#${p}" ${route === p ? 'aria-current="page"' : ""}>${n}</a>`).join("")}`;
  const view = views[route]();
  $("#content").innerHTML =
    `<div class="topline"><span class="eyebrow">${route === "investor" ? "Avelis AI / Connected ecosystem" : route === "merchant" || route === "cards" || route === "rewards" || route === "security" ? "Sharim / Optional sandbox" : "Amā / Business operating system"}</span><span class="badge">Fictional • Browser-local</span></div>${store.warning ? `<p role="alert">${esc(store.warning)}</p>` : ""}${view}`;
  document.title = `${pages.find(([p]) => p === route)[1]} | Avelis AI`;
  if (focusedId) {
    const next = document.getElementById(focusedId);
    next?.focus();
    if (typeof selection === "number" && next?.setSelectionRange)
      try {
        next.setSelectionRange(selection, selection);
      } catch {}
  }
  if (focusAction)
    [...document.querySelectorAll("[data-action]")]
      .find(
        (el) =>
          el.dataset.action === focusAction && el.dataset.key === focusKey,
      )
      ?.focus();
}
function reportSnapshot() {
  return snapshot(store.state, {
    from: chartFrom,
    to: chartTo,
    stage: chartStage,
    source: chartSource,
  });
}
function chart(values, financial = false) {
  const max = Math.max(1, ...values.map((v) => v[1]));
  return values.length
    ? values
        .map(
          ([label, value]) =>
            `<div class="chart-row"><span>${esc(label)}</span><div class="bar-track" role="img" aria-label="${esc(label)}: ${financial ? money(value) : value}"><div class="bar" style="width:${(value / max) * 100}%"></div></div><output>${financial ? money(value) : value}</output></div>`,
        )
        .join("")
    : empty(
        "No matching records. Add fictional activity or clear the filters.",
      );
}
function response(q) {
  const result = A.intelligence(store.state, q);
  if (language === "Français") {
    const m = A.metrics(store.state);
    if (/pipeline|forecast|prévision/.test(q.toLowerCase()))
      result.answer = `Prévision pondérée : ${money(m.weighted)}. Pipeline ouvert : ${money(m.pipeline)}. Calcul déterministe à partir des opportunités fictives.`;
    else if (/draft|email|rédig|follow/.test(q.toLowerCase()))
      result.answer =
        "Brouillon de démonstration : Merci pour votre examen de notre proposition fictive. Merci de confirmer votre disponibilité et vos besoins. Aucun message envoyé.";
    else
      result.answer =
        "Résultat déterministe (preuves ci-dessous) :\n" + result.answer;
  }
  return result;
}
const views = {
  investor() {
    const s = store.state;
    return `<section class="hero"><div class="eyebrow">The Connected Ecosystem</div><h1>Distinct Technologies.<br>Connected Intelligence.</h1><p>Explore a connected business journey, from first conversation to reconciled demonstration payment. Your progress follows you across every application.</p><div class="row"><a class="button" href="#discover">Start with Amā Discover →</a><a class="button" href="../index.html#demo">Avelis Command Centre ↗</a></div></section><div class="grid">${[
      [
        "Avelis AI Command Centre",
        "Integration oversight and governance",
        "../index.html#demo",
      ],
      [
        "Advisor™ Analytics",
        "CSV calculations, charts and reports",
        "../index.html#advisor-preview",
      ],
      [
        "Amā Business Operating System",
        "Customers, conversations and work",
        "#discover",
      ],
      [
        "Sharim Payments Sandbox",
        "Optional fictional payment processing",
        "#merchant",
      ],
      [
        "Investor Experience Centre",
        "Guided journey and independent exploration",
        "#investor",
      ],
    ]
      .map(([n, d, h]) =>
        card(
          n,
          `<p>${d}</p><a class="button" href="${h}">Open application →</a>`,
        ),
      )
      .join(
        "",
      )}</div><div class="two">${card("Your demonstration journey", `<div class="row">${button("Guided walkthrough", "mode-guided")}${button("Independent exploration", "mode-independent")}</div><p>Mode: ${esc(s.mode)} · ${s.progress.length}/${steps.length} milestones recorded</p><div class="progress"><span style="width:${(s.progress.length / steps.length) * 100}%"></span></div>${s.mode === "guided" ? steps.map(([r, l, k], i) => `<div class="step ${s.progress.includes(k) ? "done" : ""}"><span>${s.progress.includes(k) ? "✓" : String(i + 1).padStart(2, "0")}</span><a href="#${r}">${l}</a></div>`).join("") : "<p>Use the application navigation in any order. Milestones continue to be recorded.</p>"}<div class="row">${button("Download demonstration report", "report-html", "", "primary")}${button("Export complete records (JSON)", "report")}${button("Reset demo…", "reset")}</div><div id="reset-confirm"></div>`)}${card("What you can test", `<details open><summary>Working in this browser</summary><p>Record creation and editing, search, forecasts, CSV import/export, workflow execution, call state controls, messaging, invoice calculations, payment/refund state changes, Card Studio controls, reports, local persistence and reset.</p></details><details open><summary>Simulated external services</summary><p>Calls, transcripts, messaging, payment approval/decline/refund, rewards and coaching use explicitly fictional data. Intelligence is deterministic and rule-based. Nothing is sent to people, banks or a model.</p></details><details><summary>Requires production infrastructure</summary><p>Authentication, tenant isolation, permissions, actual AI, shared messaging, telecommunications, financial integrations, immutable audit logs and private reviewer access require secure server deployment and validation.</p></details><p>Amā is initially integrated within Avelis AI, with future independent corporation plans under Ditheka Intelligence. Avelis AI is the immediate commercial and development priority.</p><img src="assets/ditheka.png" alt="Original Ditheka Intelligence logo" style="width:100%;max-width:300px">`)}</div>`;
  },
  discover() {
    const list = store.state.ama.prospects.filter(
      (p) =>
        [p.company, p.name]
          .join(" ")
          .toLowerCase()
          .includes((filters.search || "").toLowerCase()) &&
        (!filters.industry || p.industry === filters.industry) &&
        (!filters.location || p.location === filters.location) &&
        (!filters.role || p.role === filters.role) &&
        (!filters.size || p.size >= Number(filters.size)),
    );
    return `<h1>Discover your next connection.</h1><p>Approved fictional directory. No scraping or real contact enrichment. Scores expose every criterion.</p>${card(
      "Find prospects",
      `<form id="discover-search"><div class="form-grid">${field("Company or contact", "search", filters.search || "")}${select("Industry", "industry", ["", ...new Set(store.state.ama.prospects.map((p) => p.industry))], filters.industry)}${select("Location", "location", ["", ...new Set(store.state.ama.prospects.map((p) => p.location))], filters.location)}${select("Role", "role", ["", "Director", "Founder", "Operations"], filters.role)}${select(
        "Minimum company size",
        "size",
        [
          ["", "Any"],
          ["20", "20+"],
          ["100", "100+"],
        ],
        filters.size,
      )}</div><button class="primary">Search fictional records</button></form><div class="row">${button("Export approved CSV", "prospect-export")}<label class="button">Import fictional CSV <input id="prospect-import" type="file" accept=".csv,text/csv"></label></div><p class="fine">CSV columns: company,name,industry,location,size,role,email. Only .example contact emails are accepted; explicitly confirm the dataset is fictional.</p>`,
    )}<div class="grid">${list.map((p) => card(esc(p.company), `<span class="badge">${A.leadScore(p).score}/100 transparent score</span><p><b>${esc(p.name)}</b> · ${esc(p.role)}<br>${esc(p.industry)} · ${esc(p.location)} · ${p.size} people<br>${esc(p.status)} ${esc(p.email)}</p><p>Sample buying signals: ${esc(p.signals.join("; ") || "None supplied")}</p><details><summary>Why this score?</summary><p>${A.leadScore(p).criteria}</p></details><div class="row">${button(store.state.ama.saved.includes(p.id) ? "Saved ✓" : "Save prospect", "save", p.id)}${button("Add to CRM", "add-prospect", p.id, "primary")}${button("Add to outreach", "prospect-flow", p.id)}</div>`)).join("") || empty("No matching fictional prospects. Clear filters or import an approved fictional dataset.")}</div>`;
  },
  relations() {
    const a = store.state.ama,
      c = editingContact || {},
      o = editingOpportunity || {},
      m = A.metrics(store.state);
    return `<h1>Relations</h1><p>A shared view of accounts, opportunities and next steps. Forecasts are calculated from these records.</p><div class="grid">${card("Open pipeline", `<strong>${money(m.pipeline)}</strong>`)}${card("Weighted forecast", `<strong>${money(m.weighted)}</strong><p>Σ value × probability, rounded to cents per opportunity.</p>`)}</div><div class="two">${card(c.id ? "Edit contact" : "Create fictional contact", `<form id="contact-form"><div class="form-grid">${field("Name", "name", c.name || "")}${field("Company / account", "company", c.company || "")}${field("Fictional email (.example)", "email", c.email || "", "email")}${field("Role", "role", c.role || "Contact")}${select("Lifecycle", "lifecycle", ["Lead", "Qualified", "Customer"], c.lifecycle)}</div><button class="primary">Save contact</button> ${button("Clear editor", "clear-contact")}</form>`)}${card(o.id ? "Edit opportunity" : "Create opportunity", `<form id="opportunity-form"><div class="form-grid">${field("Opportunity name", "name", o.name || "")}${select("Customer", "contact", contacts(), o.contact)}${field("Value (CAD cents)", "value", o.value || 50000, "number", 'min="0" max="100000000" required')}${field("Sales probability (%)", "probability", o.probability ?? 50, "number", 'min="0" max="100" required')}${select("Stage", "stage", a.stages, o.stage)}</div><button class="primary">Save opportunity</button> ${button("Clear editor", "clear-opportunity")}</form>`)}</div>${card(
      "Customer directory",
      `<label>Search contacts<input id="contact-search" value="${esc(query)}" placeholder="Name or company"></label>${
        a.contacts
          .filter(
            (c) =>
              !c.archived &&
              `${c.name} ${c.company}`
                .toLowerCase()
                .includes(query.toLowerCase()),
          )
          .map(
            (c) =>
              `<article class="list-item"><b>${esc(c.name)} · ${esc(c.company)}</b><small>${esc(c.email || "No approved email")} · ${esc(c.role)} · ${esc(c.source)} · ${esc(c.lifecycle || "Lead")}</small><div class="row">${button("Edit", "edit-contact", c.id)}${button("Archive", "archive-contact", c.id)}${button("Click to simulate call", "contact-call", c.id)}${button("Customer profile & timeline", "timeline", c.id)}${button("Add to outreach", "contact-flow", c.id)}</div><div id="timeline-${c.id}"></div></article>`,
          )
          .join("") ||
        empty("Create a contact or add a prospect from Discover.")
      }<details><summary>Archived contacts (${a.contacts.filter((c) => c.archived).length})</summary>${a.contacts
        .filter((c) => c.archived)
        .map(
          (c) =>
            `<p>${esc(c.name)} ${button("Restore", "restore-contact", c.id)}</p>`,
        )
        .join("")}</details>`,
    )}${card(
      "Sales pipeline",
      `<label>Search opportunities<input id="pipeline-search" value="${esc(pipelineSearch)}" placeholder="Opportunity or account"></label><form id="stages-form"><div class="row"><label>Configurable stages (comma separated; retain Won and Lost)<input name="stages" value="${esc(a.stages.join(", "))}"></label><button>Update stages</button></div></form><div class="board">${a.stages
        .map(
          (stage) =>
            `<section class="column"><h3>${esc(stage)}</h3>${
              a.opportunities
                .filter(
                  (o) =>
                    o.stage === stage &&
                    `${o.name} ${cname(o.contact)}`
                      .toLowerCase()
                      .includes(pipelineSearch.toLowerCase()),
                )
                .map(
                  (o) =>
                    `<article class="card"><b>${esc(o.name)}</b><small>${esc(cname(o.contact))}</small><p>${money(o.value)} · ${o.probability}%</p>${button("Edit / change stage", "edit-opportunity", o.id)}</article>`,
                )
                .join("") || '<p class="fine">No opportunities.</p>'
            }</section>`,
        )
        .join("")}</div>`,
    )}${card(editingAccount ? "Edit account profile" : "Create account profile", `<form id="account-form"><div class="form-grid">${field("Fictional account name", "name", editingAccount?.name || "")}${field("Industry", "industry", editingAccount?.industry || "Unspecified")}${field("Location", "location", editingAccount?.location || "Unspecified")}${field("Company size", "size", editingAccount?.size ?? 0, "number", 'min="0" max="1000000" required')}</div><button class="primary">Save account</button> ${button("Clear editor", "clear-account")}</form>`)}<div class="grid">${a.accounts
      .map((account) => {
        const ids = new Set(
            a.contacts.filter((c) => c.account === account.id).map((c) => c.id),
          ),
          opps = a.opportunities.filter((o) => ids.has(o.contact));
        return card(
          esc(account.name),
          `<p>${esc(account.industry)} · ${esc(account.location)} · ${account.size} people</p><p>${ids.size} contacts · ${opps.length} opportunities · ${money(a.invoices.filter((i) => ids.has(i.contact)).reduce((n, i) => n + i.paid, 0))} received from fictional invoices.</p><small>${esc(account.id)}</small><div class="row">${button("Edit profile", "edit-account", account.id)}</div>`,
        );
      })
      .join("")}</div>`;
  },
  connect() {
    const a = store.state.ama,
      c = a.activeCall;
    return `<h1>Connect</h1><p>Native conversation workspace · telephone simulation only. No real call is placed or received.</p><div class="two">${card("Telephone dialler", `<form id="call-form"><div class="form-grid">${select("Customer", "contact", contacts())}${field("Placeholder number", "number", "DEMO-100")}${select("Direction", "direction", ["Outbound", "Inbound"])}</div><button class="primary" ${c ? "disabled" : ""}>Start simulated call</button></form><p class="fine">No live telephone infrastructure. Use the queues below to demonstrate inbound handling.</p>`)}${card(
      "Call controls",
      c
        ? `<div class="call-state">${esc(c.status)}</div><p>${esc(cname(c.contact))} · ${esc(c.number)}<br>Participants: ${esc(c.participants.join(", "))}<br>Microphone simulation: ${c.muted ? "Muted" : "Unmuted"}</p><div class="row">${button("Connect simulation", "call-active")}${button(c.status === "Hold" ? "Resume" : "Hold", "call-hold")}${button(c.muted ? "Unmute" : "Mute", "call-mute")}${button("Complete call", "call-end", "", "primary")}</div><form id="participant-form"><div class="row">${select(
            "Colleague",
            "name",
            a.members.map((m) => m.name),
          )}<button>Add / conference participant</button>${button("Transfer to selected colleague", "call-transfer")}</div></form><div class="timeline">${c.timeline.map((t) => `<p>${esc(t.text)}</p>`).join("")}</div>`
        : empty("Choose a customer and start a simulated call."),
    )}</div>${card(
      "Call queues",
      `<form id="queue-form"><div class="form-grid">${select(
        "Queue",
        "queue",
        a.queues.map((q) => [q.id, q.name]),
      )}${select("Fictional caller", "contact", contacts())}</div><button>Add simulated inbound enquiry</button></form><div class="grid">${a.queues.map((q) => `<section><h3>${esc(q.name)} (${q.items.length})</h3>${q.items.map((item) => `<p>${esc(cname(item.contact))} ${button("Answer simulation", "queue-answer", item.id)} ${button("Remove", "queue-remove", item.id)}</p>`).join("") || '<p class="fine">Queue is empty.</p>'}</section>`).join("")}</div>`,
    )}${card("Meetings & callbacks", `<form id="meeting-form"><div class="form-grid">${field("Title", "title", "Customer callback")}${field("Date and time", "when", "", "datetime-local", "required")}${select("Customer", "contact", contacts())}</div><button>Schedule locally</button></form>${a.meetings.map((m) => `<p>${esc(m.title)} · ${esc(m.when)} · ${esc(cname(m.contact))}</p>`).join("")}`)}${card("Conversation history", a.calls.map((c) => `<article class="list-item"><b>${esc(cname(c.contact))} · ${c.status}</b><small>${esc(c.at)} · ${c.direction} · ${c.participants.length} participants</small><details><summary>Sample transcript & conversation timeline</summary>${c.transcript.map((l) => `<p><b>${esc(l.speaker)}:</b> ${esc(l.body)}</p>`).join("")}${c.timeline.map((t) => `<small>${esc(t.at)} ${esc(t.text)}</small>`).join("")}<p>Objection: cost and approval time. Commitment: quotation review next Tuesday. Action: send follow-up and confirm callback.</p>${button("Create follow-up task", "call-task", c.id)} <a class="button" href="#coach">Review coaching</a> <a class="button" href="#intelligence">Draft follow-up</a></details></article>`).join("") || empty("Completed simulated calls will appear here."))}`;
  },
  link() {
    const a = store.state.ama,
      channels = a.channels.filter((c) => c.workspace === workspace),
      messages = a.messages.filter(
        (m) =>
          m.channel === channel &&
          !m.parent &&
          m.body.toLowerCase().includes(query.toLowerCase()),
      );
    return `<h1>Link</h1><p>Company conversations, connected to work. Messages and attachments stay in this browser. Private-channel labels demonstrate organization, not access control; no multi-user communication occurs.</p>${card(
      "Workspace & conversations",
      `<div class="row"><label>Company workspace<select id="workspace">${["Demo company", "Partner demo"].map((w) => `<option ${w === workspace ? "selected" : ""}>${w}</option>`).join("")}</select></label>${channels.map((c) => `<button data-action="channel" data-key="${c.id}" class="${c.id === channel ? "primary" : ""}">${c.private ? "◈" : "#"} ${esc(c.name)}</button>`).join("")}</div><form id="channel-form"><div class="form-grid">${field("New channel or conversation name", "name")}${select("Type", "kind", ["Departmental", "Private", "Direct message", "Group"])}${select(
        "Linked project",
        "project",
        a.projects.map((p) => [p.id, p.name]),
      )}${select("Linked customer", "contact", [["", "No customer"], ...contacts()])}</div><button>Create channel</button></form>`,
    )}<div class="two">${card(
      "Conversation",
      `<label>Search messages<input id="message-search" value="${esc(query)}"></label>${
        messages
          .map(
            (m) =>
              `<article class="list-item"><span class="badge">${m.pinned ? "Pinned · " : ""}Demo participant</span><p>${esc(m.body)}</p><small>${esc(m.at)}${m.attachment ? " · Attachment: " + esc(typeof m.attachment === "object" ? m.attachment.name : m.attachment) : ""}</small><div class="row">${button("React " + (m.reactions || 0), "react", m.id)}${button(m.pinned ? "Unpin" : "Pin", "pin", m.id)}${button("Create task", "message-task", m.id)}${button("Request approval", "message-approval", m.id)}${m.attachment?.base64 ? button("Download attachment", "attachment-download", m.id) : ""}</div>${a.messages
                .filter((r) => r.parent === m.id)
                .map((r) => `<div class="thread">${esc(r.body)}</div>`)
                .join(
                  "",
                )}<form data-thread="${m.id}"><div class="row"><input name="body" aria-label="Reply to thread" required maxlength="1000"><button>Reply</button></div></form></article>`,
          )
          .join("") ||
        empty("No messages here. Send the first demonstration message.")
      }<form id="message-form"><label>Message<textarea name="body" required maxlength="2000"></textarea></label><div class="row"><label>Fictional attachment (TXT, CSV, PDF, PNG, JPG; under 500 KB)<input name="attachment" type="file" accept=".txt,.csv,.pdf,.png,.jpg,.jpeg"></label><button class="primary">Post local message</button></div></form>`,
    )}${card(
      "Conversation summary",
      `<p>Rule-based summary: ${messages.length} top-level messages in this view; ${messages.filter((m) => m.pinned).length} pinned. Tasks created from messages: ${a.tasks.filter((t) => t.message).length}.</p><p>Latest topics (verbatim excerpts):</p>${messages
        .slice(-3)
        .map((m) => `<p>“${esc(m.body.slice(0, 180))}”</p>`)
        .join(
          "",
        )}<a class="button" href="#teams">Open linked tasks</a><a class="button" href="#connect">Schedule a meeting</a>`,
    )}</div>`;
  },
  flow() {
    const a = store.state.ama;
    return `<h1>Flow</h1><p>Build and execute local outreach workflows. Each step creates connected tasks or waits for an explicit approval. A Condition step checks whether the customer has an approved fictional email; Approval creates a manager decision task.</p>${card(
      "Workflow builder",
      `<form id="workflow-form"><div class="form-grid">${field("Workflow name", "name", "New customer outreach")}${select("Customer", "contact", contacts())}${select(
        "Assign to",
        "assignee",
        a.members.map((m) => m.name),
      )}${field("Start date (optional)", "scheduled", "", "date")}${select("Template", "template", ["Outreach", "Customer follow-up", "Manager approval"])}</div><label>Steps (one per line: Call, Email, Condition or Approval followed by : and description)<textarea name="steps">Call: Introduce offer\nCondition: Continue if fictional email exists\nEmail: Draft follow-up\nApproval: Review proposal</textarea></label><button class="primary">Create workflow</button></form>`,
    )}${a.workflows.map((w) => card(esc(w.name), `<span class="badge">${w.status}</span><p>${esc(cname(w.contact))} · ${esc(w.assignee)} · ${w.scheduled || "Available now"}</p><ol>${w.steps.map((s, i) => `<li>${i < w.cursor ? "✓ " : ""}${esc(s.kind)} · ${esc(s.title)}</li>`).join("")}</ol><div class="row">${button("Execute next step", "flow-execute", w.id, "primary")}${button("Pause", "flow-pause", w.id)}${button("Resume / continue after approval", "flow-resume", w.id)}${button("Cancel", "flow-cancel", w.id)}</div><details><summary>Execution history</summary>${w.history.map((h) => `<p>${esc(h.at)} · ${esc(h.text)}</p>`).join("") || "<p>Not started.</p>"}</details>`)).join("") || empty("Build a workflow or add a prospect to outreach in Discover.")}`;
  },
  intelligence() {
    return `<h1>Intelligence</h1><p>A transparent business assistant. These responses use fixed rules and your demonstration records; no model is configured.</p>${card("Ask about your business", `<form id="intelligence-form"><div class="form-grid">${select("Response language", "language", ["English", "Français"], language)}</div><label>Business query<textarea name="query" required placeholder="Pipeline forecast, customer summary, follow-up draft, workflow recommendations…"></textarea></label><div class="row"><button class="primary">Run deterministic query</button>${button("Pipeline forecast", "query-pipeline")}${button("Customer summary", "query-customer")}</div></form>${answer ? `<div class="timeline"><pre>${esc(answer.answer)}</pre><p class="fine">Evidence record IDs: ${esc(answer.refs.join(", ") || "No matching records; rule/interface guidance only.")}</p></div>` : ""}`)}${card("Document analysis interface", `<p>Local text inspection counts words and cites lines containing explicit business terms. It does not interpret documents with AI.</p><label>Load fictional text or CSV<input id="document-upload" type="file" accept=".txt,.csv,text/plain,text/csv"></label><form id="document-form"><label>Fictional document text<textarea name="document" maxlength="100000" required></textarea></label><button>Inspect text locally</button></form><div id="document-result"></div>`)}${card("Secure model adapter", `<p>The unconfigured server adapter in core/adapters.js defines the future integration boundary. Production inference needs authentication, authorization, rate limits and server-held secrets. Never paste API keys here.</p>`)}`;
  },
  coach() {
    const a = store.state.ama;
    return `<h1>Coach</h1><p>Evidence-based transcript checks. Scores use configurable text criteria and do not infer emotions or personality.</p>${card(
      "Coaching criteria",
      `<form id="criteria-form"><div class="form-grid">${Object.entries(
        a.criteria,
      )
        .map(([k, v]) =>
          field(
            k + " weight",
            "" + k,
            v,
            "number",
            'min="0" max="100" required',
          ),
        )
        .join("")}</div><button>Update scoring weights</button></form>`,
    )}${
      a.calls
        .map((c) => {
          const x = A.coach(c, a.criteria);
          return card(
            `${esc(cname(c.contact))} · ${x.score}/100`,
            `${c.transcript.map((l) => `<p><b>${esc(l.speaker)}:</b> ${esc(l.body)}</p>`).join("")}<div class="grid">${x.evidence.map((e) => `<div><b>${e.pass ? "✓" : "—"} ${e.label}</b><p>Weight ${e.weight}. Evidence: “${esc(e.evidence)}”</p></div>`).join("")}</div>${button("Mark transcript reviewed", "coach-reviewed", c.id)} ${button("Create follow-up action", "call-task", c.id)}`,
          );
        })
        .join("") ||
      empty(
        "Complete a simulated call in Connect to review its labelled sample transcript.",
      )
    }`;
  },
  teams() {
    const a = store.state.ama;
    return `<h1>Teams</h1><p>Departments, deadlines and connected tasks.</p><div class="grid">${a.members.map((m) => card(esc(m.name), `<p>${esc(m.department)} · Fictional team directory</p>`)).join("")}${a.projects
      .map((p) => {
        const ts = a.tasks.filter((t) => t.project === p.id),
          done = ts.filter((t) => t.status === "Done").length;
        return card(
          esc(p.name),
          `<p>Deadline ${p.deadline} · ${done}/${ts.length} completed</p><div class="progress"><span style="width:${ts.length ? (done / ts.length) * 100 : 0}%"></span></div>`,
        );
      })
      .join(
        "",
      )}</div>${card("Project management", `<form id="project-form"><div class="form-grid">${field("Project name", "name")}${field("Project deadline", "deadline", "", "date", "required")}</div><button>Create project</button></form>`)}${card(
      editingTask ? "Edit assignment & follow-up" : "Create a task or approval",
      `<form id="task-form"><div class="form-grid">${field("Task title", "title", editingTask?.title || "")}${select("Customer", "contact", [["", "No customer"], ...contacts()], editingTask?.contact)}${select("Opportunity", "opportunity", [["", "No opportunity"], ...a.opportunities.map((o) => [o.id, o.name])], editingTask?.opportunity)}${select(
        "Project",
        "project",
        a.projects.map((p) => [p.id, p.name]),
        editingTask?.project,
      )}${select(
        "Assign to",
        "assignee",
        a.members.map((m) => m.name),
        editingTask?.assignee,
      )}${field("Due date", "due", editingTask?.due || "", "date")}${select("Type", "type", ["Task", "Approval"], editingTask?.approval ? "Approval" : "Task")}</div><button class="primary">Save task</button> ${button("Clear editor", "clear-task")}</form>`,
    )}<div class="board">${["Open", "Pending approval", "Approved", "Done"]
      .map(
        (status) =>
          `<section class="column"><h3>${status}</h3>${
            a.tasks
              .filter((t) => t.status === status)
              .map(
                (t) =>
                  `<article class="card"><b>${esc(t.title)}</b><p>${esc(t.assignee)} · ${esc(t.due)}<br>${esc(cname(t.contact))}</p><small>${t.due < new Date().toISOString().slice(0, 10) && t.status !== "Done" ? "Overdue reminder · " : ""}Linked: ${esc([t.message, t.opportunity, t.project].filter(Boolean).join(" · "))}</small><div class="row">${button("Edit assignment", "edit-task", t.id)}${t.approval && status === "Pending approval" ? button("Approve locally", "approve-task", t.id) : ""}${status !== "Done" && status !== "Pending approval" ? button("Complete", "done-task", t.id) : ""}</div></article>`,
              )
              .join("") || '<p class="fine">No tasks.</p>'
          }</section>`,
      )
      .join("")}</div>`;
  },
  insights() {
    const snap = reportSnapshot(),
      m = snap.metrics;
    return `<h1>Insights</h1><p>Every dashboard and export is calculated from the same filtered connected records. Won conversion = won opportunities ÷ all filtered opportunities.</p>${card("Reporting filters", `<form id="range-form"><div class="form-grid">${field("From", "from", chartFrom, "date")}${field("Through", "to", chartTo, "date")}${select("Opportunity stage", "stage", [["", "All stages"], ...store.state.ama.stages], chartStage)}${select("Lead source", "source", [["", "All sources"], ...new Set(store.state.ama.contacts.map((c) => c.source))], chartSource)}</div><button class="primary">Apply filters</button> ${button("Clear filters", "clear-range")}</form><p class="fine">Date range applies to opportunities, calls, invoices and payments. Task/workflow charts show current state for selected customers. Stage filters relate invoices/payments through their opportunity.</p>`)}<div class="grid">${[
      ["Pipeline", money(m.pipeline)],
      ["Weighted forecast", money(m.weighted)],
      ["Won conversion", m.conversion.toFixed(1) + "%"],
      ["Completed calls", m.calls],
      ["Outstanding tasks", m.tasks],
      ["Completed workflows", m.workflows],
      ["Invoice total", money(m.invoiced)],
      ["Paid invoices", money(m.paid)],
    ]
      .map(
        ([l, v]) =>
          `<div class="card metric"><small>${l}</small><strong>${v}</strong></div>`,
      )
      .join("")}</div><div class="grid">${Object.entries(snap.charts)
      .map(([key, values]) =>
        card(
          {
            pipeline: "Pipeline value by stage",
            sources: "Lead sources",
            calls: "Call activity",
            tasks: "Task status",
            workflows: "Workflow execution",
            invoices: "Invoice status",
            payments: "Payment activity",
          }[key],
          chart(values, ["pipeline", "invoices", "payments"].includes(key)),
        ),
      )
      .join(
        "",
      )}</div><div class="row">${button("Download filtered insights CSV", "insights-export", "", "primary")}${button("Send generated dataset to Advisor™", "advisor")}${button("Mark insights reviewed", "insights-reviewed")}</div>`;
  },
  commerce() {
    const a = store.state.ama,
      i = editingInvoice;
    return `<h1>Commerce</h1><p>Fictional quotations, orders and invoices. Amā continues to work when Sharim is disconnected.</p>${card(i ? "Edit invoice" : "Create invoice", `<form id="invoice-form"><div class="form-grid">${select("Customer", "contact", contacts(), i?.contact)}${select("Related opportunity", "opportunity", [["", "None"], ...a.opportunities.map((o) => [o.id, o.name])], i?.opportunity)}</div><div id="invoice-lines">${(i?.lines || [{ description: "Fictional service", quantity: 1, unit: 50000 }]).map((l) => lineEditor(l)).join("")}</div><div class="row">${button("Add line", "invoice-line")}<output id="invoice-preview">${money(i ? A.total(i) : 50000)}</output></div><button class="primary">Save invoice</button> ${button("Clear editor", "clear-invoice")}</form>`)}${card("Invoices & customer billing history", a.invoices.map((i) => `<article class="list-item"><b>${esc(cname(i.contact))} · ${money(A.total(i))}</b> <span class="badge">${i.status}</span><small>${esc(i.id)} · paid ${money(i.paid)} · ${esc(i.at)}</small><p>${i.lines.map((l) => `${esc(l.description)} × ${l.quantity} at ${money(l.unit)}`).join("<br>")}</p><div class="row">${button("Edit lines", "edit-invoice", i.id)}${button("Download invoice", "invoice-download", i.id)}${button("Create quotation", "quote", i.id)}${button("Create order", "order", i.id)}${button("Payment request", "payment-request", i.id)}</div></article>`).join("") || empty("Create your first fictional invoice."))}${card("Quotations & orders", `<p>Quotations: ${a.quotes.length} · Orders: ${a.orders.length}</p>${a.quotes.map((o) => `<article class="list-item"><b>Quotation · ${money(o.amount)} · ${esc(o.status)}</b><small>${esc(o.id)} · ${esc(o.invoice)}</small><div class="row">${button("Download quotation", "quote-download", o.id)}${o.status === "Draft quotation" ? button("Accept & create order", "quote-accept", o.id) + button("Decline", "quote-decline", o.id) : ""}</div></article>`).join("")}${a.orders.map((o) => `<article class="list-item"><b>Order · ${money(o.amount)} · ${esc(o.status)}</b><small>${esc(o.id)} · ${esc(o.invoice)}</small><div class="row">${!["Fulfilled", "Cancelled"].includes(o.status) ? button("Mark fulfilled", "order-fulfill", o.id) + button("Cancel order", "order-cancel", o.id) : ""}</div></article>`).join("")}`)}`;
  },
  merchant() {
    const s = store.state,
      sh = s.sharim,
      tx = sh.transactions.filter((t) =>
        `${t.id} ${t.status} ${t.invoice}`
          .toLowerCase()
          .includes(query.toLowerCase()),
      );
    return `<img class="brand-image" src="assets/sharim.jpg" alt="Original Sharim blue logo"><h1>Merchant sandbox</h1><p>Live Fully With Every Connected Purchase.<br>Optional Sharim integration under Maarah. No money moves; no financial credentials are collected.</p><div class="row"><span class="badge">${sh.connected ? "Connected" : "Disconnected"}</span>${button(sh.connected ? "Disconnect sandbox" : "Connect optional Sharim", "toggle-sharim", "", "primary")}</div><div class="grid">${card("Settlement preview", `<strong>${money(S.settlement(s))}</strong><p>Approved gross less demonstration fees. Refunded fees are reversed in this simulation.</p>`)}${card("Reconciliation", `<p>Approved net matches invoice receipts: ${sh.transactions.filter((t) => t.status === "Approved").reduce((n, t) => n + t.amount, 0) === s.ama.invoices.reduce((n, i) => n + i.paid, 0) ? "Balanced" : "Mismatch — inspect records"}</p><p>${sh.transactions.length} transaction records; ${sh.requests.length} payment requests.</p>`)}</div>${card(
      "Simulate invoice payment",
      `<form id="payment-form"><div class="form-grid">${select(
        "Invoice",
        "invoice",
        s.ama.invoices.map((i) => [
          i.id,
          `${cname(i.contact)} · ${money(A.total(i))} · ${i.status} · ${i.id.slice(-6)}`,
        ]),
      )}${select(
        "Card module",
        "module",
        sh.modules.map((m) => [m.id, m.name]),
      )}${select("Result", "status", ["Approved", "Declined"])}${field("Idempotency key (reuse to prevent duplicate processing)", "key", id("REQUEST"), "text", 'required maxlength="120"')}</div><button class="primary">Process fictional transaction</button></form><p class="fine">Use only placeholder identifiers. Approved and refunded transactions update the linked invoice, module spending and reports.</p>`,
    )}${card("Configurable demo fees", `<form id="fees-form"><div class="form-grid">${field("Basis points (250 = 2.5%)", "bps", sh.feeBps, "number", 'min="0" max="1000" required')}${field("Fixed fee (CAD cents)", "fixed", sh.fixedFee, "number", 'min="0" max="1000" required')}</div><button>Save fees for future transactions</button></form>`)}${card("Transaction history", `<label>Search transactions<input id="transaction-search" value="${esc(query)}"></label><div class="table-wrap"><table><thead><tr><th>Transaction / invoice</th><th>Status</th><th>Gross</th><th>Fee</th><th>Action</th></tr></thead><tbody>${tx.map((t) => `<tr><td>${esc(t.id)}<br>${esc(t.invoice)}</td><td>${t.status}</td><td>${money(t.amount)}</td><td>${money(t.fee)}</td><td>${t.status === "Approved" ? button("Refund", "refund", t.id) : ""}${button("Receipt", "receipt", t.id)}</td></tr>`).join("")}</tbody></table></div>${!tx.length ? empty("No matching transactions. Create an invoice in Commerce, then simulate a payment.") : ""}<div class="row">${button("Download transaction CSV", "transaction-export")}${button("Mark transactions reviewed", "merchant-reviewed")}</div>`)}${card("Payment requests", sh.requests.map((r) => `<p>${esc(r.id)} · ${esc(r.invoice)} · ${esc(s.ama.invoices.find((i) => i.id === r.invoice)?.status || "Unknown")}</p>`).join("") || "<p>No payment requests yet. Create one from an Amā invoice.</p>")}`;
  },
  cards() {
    const sh = store.state.sharim;
    return `<h1>Card Studio</h1><p>Four pieces. One interactive concept. Placeholder module identifiers only.</p><div class="card"><b>Unvalidated physical engineering concept</b><p>This virtual assembly does not establish payment-terminal compatibility, hardware certification or active financial infrastructure. Public controls do not expose mechanical design or confidential payment architecture.</p><p>Original founder-supplied artwork, cropped with permission to exclude specifications and personal-looking details. Module controls change only the fictional demonstration state.</p><div class="row">${button("Connected-card mode", "cards-connected")}${button("Individual-module mode", "cards-individual")}${button("Assemble all", "cards-assemble")}${button("Detach all", "cards-detach")}</div><span class="badge">${esc(sh.mode)} mode · ${sh.modules.filter((m) => m.attached).length}/4 assembled</span></div>${card("Your virtual assembly", `<div class="assembly"><img src="assets/sharim-assembled.png" alt="Original founder-approved four-piece Sharim card artwork"><div class="assembly-controls">${sh.modules.map((m) => `<button data-action="module-attach" data-key="${m.id}" class="${m.attached ? "assembled" : "vacant"}" aria-label="${m.attached ? "Detach" : "Assemble"} ${esc(m.name)}">${m.attached ? "✓" : "+"} ${esc(m.name)}</button>`).join("")}</div></div><p class="fine">Choose a piece above or its control below. ${sh.modules.filter((m) => m.attached).length}/4 pieces assembled.</p>`)}<div class="modules">${sh.modules
      .map(
        (m, i) =>
          `<section class="module ${m.attached ? "" : "detached"} ${m.frozen ? "frozen" : ""}"><img class="module-art" src="assets/sharim-module-${i + 1}.png" alt="Original Sharim ${esc(m.name)} module artwork"><h2>${String(i + 1).padStart(2, "0")} ${esc(m.name)}</h2><p>${["Primary daily spending", "Groceries, subscriptions and controlled daily expenses", "Business and shared household expenses", "Emergency reserves and eligible larger purchases"][i]}</p><p>${m.attached ? "Assembled" : "Detached"} · ${m.frozen ? "Frozen" : "Active"}<br>${esc(m.id)} · spent ${money(m.spent)}</p><div class="row">${button(m.attached ? "Detach" : "Assemble", "module-attach", m.id)}${button(m.frozen ? "Reactivate" : "Freeze", "module-freeze", m.id)}</div><form data-module="${m.id}">${field("Demo limit (CAD cents)", "limit", m.limit, "number", 'min="0" max="100000000" required')}<button>Save limit</button></form><details><summary>Fictional module activity</summary>${
            sh.transactions
              .filter((t) => t.module === m.id)
              .map(
                (t) => `<p>${esc(t.id)} · ${t.status} · ${money(t.amount)}</p>`,
              )
              .join("") || "<p>No activity.</p>"
          }</details></section>`,
      )
      .join("")}</div>`;
  },
  rewards() {
    const sh = store.state.sharim;
    return `<h1>Rewards</h1><p>Fictional merchant benefits; no redeemable value.</p>${card("Transaction-linked points", `<div class="metric"><strong>${sh.transactions.reduce((n, t) => n + t.points, 0)}</strong><small>Current demonstration points · refunded payments reverse points</small></div><form id="benefit-form">${field("Fictional merchant name", "merchant", sh.merchant)}${field("Merchant benefit description", "description", sh.benefitDescription || "Demonstration loyalty points")}${field("Points per CAD dollar (future transactions)", "points", sh.benefit, "number", 'min="0" max="100" required')}<button>Save merchant benefit</button></form>`)}`;
  },
  security() {
    const s = store.state;
    return `<h1>Security & governance</h1><p>Local demonstration controls and inspectable events. This is not a banking security certification or immutable audit service.</p>${card("Sandbox account controls", `<div class="row">${button(s.sharim.permissions ? "Disable spending permission" : "Enable spending permission", "permission")}${button(s.sharim.alerts ? "Disable simulated alerts" : "Enable simulated alerts", "alerts")}${button("Record governance review", "audit-reviewed")}</div><p>Spending permission: ${s.sharim.permissions ? "Enabled" : "Disabled"} · Alerts: ${s.sharim.alerts ? "Enabled" : "Disabled"}</p><p>Freeze individual modules in Card Studio. No banking licence, issuing-bank relationship, network membership or certified financial infrastructure is claimed.</p>`)}${card(
      "Simulated transaction alerts",
      s.sharim.notifications
        .slice(-15)
        .reverse()
        .map((n) => `<p>${esc(n.at)} · ${esc(n.text)}</p>`)
        .join("") ||
        empty(
          "No simulated alerts. Enable alerts, then process a fictional transaction.",
        ),
    )}${card(
      "Versioned integration audit",
      `<p>Events persist locally and are sent to the existing Avelis demo audit when its page opens. They are editable browser records, not certified audit evidence.</p>${
        s.events
          .slice(-60)
          .reverse()
          .map(
            (e) =>
              `<div class="list-item"><b>${esc(e.type)}</b><small>v${e.version} · ${esc(e.at)} · ${esc(e.id)}</small><pre>${esc(JSON.stringify(e.detail))}</pre></div>`,
          )
          .join("") || empty("No ecosystem events yet.")
      }`,
    )}`;
  },
};
function lineEditor(l) {
  return `<div class="form-grid invoice-line">${field("Description", "description", l.description)}${field("Quantity", "quantity", l.quantity, "number", 'min="1" max="10000" required')}${field("Unit price (CAD cents)", "unit", l.unit, "number", 'min="0" max="10000000" required')}${button("Remove line", "remove-line")}</div>`;
}
$("#content").addEventListener("click", (e) => {
  const b = e.target.closest("[data-action]");
  if (!b) return;
  e.preventDefault();
  const k = b.dataset.key,
    a = b.dataset.action,
    s = store.state;
  try {
    if (a === "reset") {
      $("#reset-confirm").innerHTML =
        "<p>This resets only ecosystem records; original Avelis storage remains intact.</p>" +
        button("Confirm reset", "confirm-reset") +
        button("Keep records", "keep-records");
      return;
    }
    if (a === "keep-records") {
      $("#reset-confirm").replaceChildren();
      return;
    }
    if (a === "confirm-reset") {
      store.reset();
      channel = "CH-1";
      workspace = "Demo company";
      query = "";
      pipelineSearch = "";
      filters = {};
      chartFrom = chartTo = chartStage = chartSource = "";
      answer = null;
      editingContact =
        editingOpportunity =
        editingInvoice =
        editingTask =
        editingAccount =
          null;
      render();
      notice("Ecosystem demonstration reset.");
      return;
    }
    if (a === "remove-line") {
      b.closest(".invoice-line").remove();
      updateInvoicePreview();
      return;
    }
    if (a === "invoice-line") {
      $("#invoice-lines").insertAdjacentHTML(
        "beforeend",
        lineEditor({
          description: "Fictional service",
          quantity: 1,
          unit: 10000,
        }),
      );
      updateInvoicePreview();
      return;
    }
    if (a === "timeline") {
      const c = s.ama.contacts.find((c) => c.id === k);
      $(`#timeline-${k}`).innerHTML =
        `<div class="timeline"><p>Created ${esc(c.created)}</p>${s.ama.opportunities
          .filter((o) => o.contact === k)
          .map(
            (o) =>
              `<p>${esc(o.name)} · ${esc(o.stage)} · ${money(o.value)}</p>`,
          )
          .join("")}${s.ama.calls
          .filter((o) => o.contact === k)
          .map((o) => `<p>Completed simulated call ${esc(o.at)}</p>`)
          .join("")}${s.ama.tasks
          .filter((o) => o.contact === k)
          .map((o) => `<p>${esc(o.title)} · ${esc(o.status)}</p>`)
          .join("")}${s.ama.invoices
          .filter((o) => o.contact === k)
          .map(
            (o) =>
              `<p>Invoice ${esc(o.id)} · ${o.status} · ${money(o.paid)} received</p>`,
          )
          .join("")}</div>`;
      return;
    }
    if (a === "edit-contact") {
      editingContact = structuredClone(s.ama.contacts.find((x) => x.id === k));
      render();
      return;
    }
    if (a === "clear-contact") {
      editingContact = null;
      render();
      return;
    }
    if (a === "edit-opportunity") {
      editingOpportunity = structuredClone(
        s.ama.opportunities.find((x) => x.id === k),
      );
      render();
      $("#opportunity-form").scrollIntoView({ block: "center" });
      return;
    }
    if (a === "clear-opportunity") {
      editingOpportunity = null;
      render();
      return;
    }
    if (a === "edit-invoice") {
      editingInvoice = structuredClone(s.ama.invoices.find((x) => x.id === k));
      render();
      return;
    }
    if (a === "clear-invoice") {
      editingInvoice = null;
      render();
      return;
    }
    if (a === "channel") {
      channel = k;
      render();
      return;
    }
    if (a === "edit-account") {
      editingAccount = structuredClone(s.ama.accounts.find((a) => a.id === k));
      render();
      $("#account-form").scrollIntoView({ block: "center" });
      return;
    }
    if (a === "clear-account") {
      editingAccount = null;
      render();
      return;
    }
    if (a === "edit-task") {
      editingTask = structuredClone(s.ama.tasks.find((t) => t.id === k));
      render();
      $("#task-form").scrollIntoView({ block: "center" });
      return;
    }
    if (a === "clear-task") {
      editingTask = null;
      render();
      return;
    }
    if (a === "attachment-download") {
      const file = s.ama.messages.find((m) => m.id === k)?.attachment;
      download(file.name, attachmentBytes(file), file.type);
      return;
    }
    if (a === "report-html") {
      change("report.downloaded", (s) => mark(s, "report"));
      download(
        "avelis-investor-demonstration-report.html",
        investorHTML(store.state, A.metrics(store.state), steps),
        "text/html",
      );
      return;
    }
    if (a === "report") {
      change("report.downloaded", (s) => mark(s, "report"));
      download(
        "avelis-connected-demo-report.json",
        JSON.stringify(report(), null, 2),
        "application/json",
      );
      return;
    }
    if (a === "advisor") {
      const dataset = advisorDataset(s);
      if (!dataset.rows.length)
        throw Error("Simulate a transaction before sending a dataset.");
      localStorage.setItem(
        "avelis-ecosystem-advisor-v1",
        JSON.stringify(dataset),
      );
      change("advisor.dataset.exported", (s) => mark(s, "advisor"), {
        rows: dataset.rows.length,
      });
      location.href = "../index.html?ecosystem=advisor#advisor-preview";
      return;
    }
    if (a === "prospect-export") {
      download(
        "approved-fictional-prospects.csv",
        csv([
          ["company", "name", "industry", "location", "size", "role", "email"],
          ...s.ama.prospects.map((p) => [
            p.company,
            p.name,
            p.industry,
            p.location,
            p.size,
            p.role,
            p.email,
          ]),
        ]),
        "text/csv",
      );
      return;
    }
    if (a === "insights-export") {
      const snap = reportSnapshot();
      download(
        "ama-insights.csv",
        csv([
          ["metric", "value"],
          ...Object.entries(snap.metrics),
          ...Object.entries(snap.charts).flatMap(([chart, values]) =>
            values.map(([label, v]) => [chart + ": " + label, v]),
          ),
        ]),
        "text/csv",
      );
      return;
    }
    if (a === "transaction-export") {
      download(
        "sharim-fictional-transactions.csv",
        csv([
          ["id", "invoice", "status", "amount_cents", "fee_cents", "points"],
          ...s.sharim.transactions.map((t) => [
            t.id,
            t.invoice,
            t.status,
            t.amount,
            t.fee,
            t.points,
          ]),
        ]),
        "text/csv",
      );
      return;
    }
    if (a === "receipt") {
      const t = s.sharim.transactions.find((t) => t.id === k);
      download(
        "fictional-receipt-" + k + ".html",
        receiptHTML(s, t),
        "text/html",
      );
      return;
    }
    if (a === "quote-download") {
      const q = s.ama.quotes.find((q) => q.id === k),
        i = s.ama.invoices.find((i) => i.id === q.invoice);
      download(
        "fictional-quotation-" + k + ".html",
        invoiceHTML(s, { ...i, ...q, paid: 0 }, q.amount, "quotation"),
        "text/html",
      );
      return;
    }
    if (a === "invoice-download") {
      const i = s.ama.invoices.find((i) => i.id === k);
      download(
        "fictional-invoice-" + k + ".html",
        invoiceHTML(s, i, A.total(i)),
        "text/html",
      );
      return;
    }
    if (a === "query-pipeline" || a === "query-customer") {
      answer = response(a === "query-pipeline" ? "pipeline" : "customer");
      render();
      return;
    }
    if (a === "clear-range") {
      chartFrom = chartTo = chartStage = chartSource = "";
      render();
      return;
    }
    change(
      a,
      (state) => {
        const ama = state.ama,
          sh = state.sharim;
        if (a.startsWith("mode-")) state.mode = a.slice(5);
        else if (a === "save") {
          if (!ama.saved.includes(k)) ama.saved.push(k);
        } else if (a === "add-prospect") {
          A.addProspect(state, k);
          mark(state, "contact");
        } else if (a === "prospect-flow") {
          const c = A.addProspect(state, k);
          A.workflow(state, { name: "Outreach · " + c.company, contact: c.id });
          mark(state, "contact");
          mark(state, "flow");
        } else if (a === "archive-contact" || a === "restore-contact")
          ama.contacts.find((c) => c.id === k).archived =
            a === "archive-contact";
        else if (a === "contact-flow") {
          A.workflow(state, { name: "Outreach · " + cname(k), contact: k });
          mark(state, "flow");
        } else if (a === "queue-answer" || a === "queue-remove") {
          const queue = ama.queues.find((q) => q.items.some((i) => i.id === k));
          if (!queue) throw Error("Queue item not found.");
          const item = queue.items.find((i) => i.id === k);
          if (a === "queue-answer") {
            A.call(state, "start", {
              contact: item.contact,
              direction: "Inbound",
              number: "DEMO-INBOUND",
            });
            mark(state, "call");
          }
          queue.items = queue.items.filter((i) => i.id !== k);
        } else if (a === "contact-call") {
          A.call(state, "start", { contact: k });
          mark(state, "call");
        } else if (a === "call-transfer") {
          const name = $("#participant-form select").value;
          A.call(state, "transfer", { name });
          mark(state, "participant");
        } else if (a.startsWith("call-") && a !== "call-task")
          A.call(state, a.slice(5));
        else if (a === "call-task") {
          const c = ama.calls.find((c) => c.id === k);
          A.task(state, {
            title: "Send quotation follow-up and confirm callback",
            contact: c.contact,
          });
          mark(state, "task");
        } else if (a === "react")
          ama.messages.find((m) => m.id === k).reactions++;
        else if (a === "pin") {
          const m = ama.messages.find((m) => m.id === k);
          m.pinned = !m.pinned;
        } else if (a === "message-task" || a === "message-approval") {
          const m = ama.messages.find((m) => m.id === k);
          A.task(state, {
            title: m.body.slice(0, 300),
            message: m.id,
            project: ama.channels.find((c) => c.id === m.channel)?.project,
            contact: ama.channels.find((c) => c.id === m.channel)?.contact,
            approval: a === "message-approval",
          });
          mark(state, "task");
        } else if (a.startsWith("flow-"))
          A.runWorkflow(
            state,
            ama.workflows.find((w) => w.id === k),
            a.slice(5),
          );
        else if (a === "done-task")
          ama.tasks.find((t) => t.id === k).status = "Done";
        else if (a === "approve-task")
          ama.tasks.find((t) => t.id === k).status = "Approved";
        else if (a === "coach-reviewed") mark(state, "coach");
        else if (a === "insights-reviewed") mark(state, "insights");
        else if (a === "merchant-reviewed") mark(state, "merchant");
        else if (a === "audit-reviewed") mark(state, "audit");
        else if (a === "quote" || a === "order") {
          const i = ama.invoices.find((i) => i.id === k);
          ama[a === "quote" ? "quotes" : "orders"].push({
            id: id(a === "quote" ? "QUOTE" : "ORDER"),
            invoice: k,
            amount: A.total(i),
            status: a === "quote" ? "Draft quotation" : "Queued",
            contact: i.contact,
            lines: structuredClone(i.lines),
            at: date(),
          });
        } else if (a === "quote-accept" || a === "quote-decline") {
          const quote = ama.quotes.find((q) => q.id === k);
          if (!quote || quote.status !== "Draft quotation")
            throw Error("Only a draft quotation may be decided.");
          quote.status = a === "quote-accept" ? "Accepted" : "Declined";
          if (quote.status === "Accepted")
            ama.orders.push({
              ...structuredClone(quote),
              id: id("ORDER"),
              quote: quote.id,
              status: "Queued",
              at: date(),
            });
        } else if (a === "order-fulfill" || a === "order-cancel") {
          const order = ama.orders.find((o) => o.id === k);
          if (!order || ["Fulfilled", "Cancelled"].includes(order.status))
            throw Error("Order is already finalized.");
          order.status = a === "order-fulfill" ? "Fulfilled" : "Cancelled";
        } else if (a === "payment-request") {
          if (!sh.requests.some((r) => r.invoice === k))
            sh.requests.push({ id: id("PAYREQ"), invoice: k, at: date() });
        } else if (a === "toggle-sharim") {
          sh.connected = !sh.connected;
          if (sh.connected) mark(state, "connected");
        } else if (a === "refund") S.refund(state, k);
        else if (a === "permission") sh.permissions = !sh.permissions;
        else if (a === "alerts") sh.alerts = !sh.alerts;
        else if (a === "cards-connected" || a === "cards-individual")
          sh.mode = a.slice(6);
        else if (a === "cards-assemble" || a === "cards-detach")
          sh.modules.forEach((m) => (m.attached = a === "cards-assemble"));
        else if (a === "module-attach") {
          const m = sh.modules.find((m) => m.id === k);
          m.attached = !m.attached;
        } else if (a === "module-freeze") {
          const m = sh.modules.find((m) => m.id === k);
          m.frozen = !m.frozen;
        } else throw Error("Unknown application action.");
      },
      { record: k },
    );
    if (a === "contact-call") move("connect");
    else render();
    notice("Demonstration records updated.");
  } catch (err) {
    notice(err.message);
  }
});
$("#content").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target,
    d = Object.fromEntries(new FormData(f));
  if (f.id === "import-confirm") return;
  try {
    if (f.id === "discover-search") {
      filters = d;
      change("prospects.searched", (s) => mark(s, "searched"));
      render();
      return;
    }
    if (f.id === "range-form") {
      if (d.from && d.to && d.from > d.to)
        throw Error("Start date must precede end date.");
      chartFrom = d.from;
      chartTo = d.to;
      chartStage = d.stage || "";
      chartSource = d.source || "";
      render();
      return;
    }
    if (f.id === "intelligence-form") {
      language = d.language;
      answer = response(d.query);
      render();
      return;
    }
    if (f.id === "document-form") {
      const x = inspectDocument(d.document);
      $("#document-result").innerHTML =
        `<p>${x.words} words · ${x.characters} characters · ${x.lines} lines. Local rule-based inspection only.</p>${x.evidence.map((e) => `<details><summary>${esc(e.term)}: ${e.matches.length} matching lines</summary>${e.matches.map((l) => `<p>Line ${l.line}: “${esc(l.body)}”</p>`).join("") || "<p>No explicit matching text.</p>"}</details>`).join("")}`;
      return;
    }
    const attached =
      f.id === "message-form"
        ? await attachment(f.elements.attachment.files[0])
        : null;
    change(f.id || "record.updated", (s) => {
      const a = s.ama,
        sh = s.sharim;
      if (f.id === "account-form") {
        A.account(s, { ...d, accountId: editingAccount?.id });
        editingAccount = null;
      } else if (f.id === "contact-form") {
        A.contact(s, { ...d, id: editingContact?.id });
        editingContact = null;
        mark(s, "contact");
      } else if (f.id === "opportunity-form") {
        A.opportunity(s, { ...d, id: editingOpportunity?.id });
        editingOpportunity = null;
        mark(s, "opportunity");
        if (d.stage === "Won") mark(s, "won");
      } else if (f.id === "stages-form") {
        const stages = [
          ...new Set(d.stages.split(",").map((x) => text(x, 50))),
        ];
        if (
          !stages.includes("Won") ||
          !stages.includes("Lost") ||
          stages.length > 12 ||
          a.opportunities.some((o) => !stages.includes(o.stage))
        )
          throw Error(
            "Retain Won, Lost and stages used by existing opportunities. Maximum 12.",
          );
        a.stages = stages;
      } else if (f.id === "call-form") {
        A.call(s, "start", d);
        mark(s, "call");
      } else if (f.id === "participant-form") {
        A.call(s, "participant", d);
        mark(s, "participant");
      } else if (f.id === "queue-form") {
        if (!a.contacts.some((c) => c.id === d.contact))
          throw Error("Add a CRM customer first.");
        a.queues
          .find((q) => q.id === d.queue)
          .items.push({ id: id("QI"), contact: d.contact, at: date() });
      } else if (f.id === "meeting-form") {
        if (!d.when || !Number.isFinite(Date.parse(d.when)))
          throw Error("Select a valid date and time.");
        a.meetings.push({
          id: id("MEET"),
          title: text(d.title),
          when: d.when,
          contact: d.contact,
        });
      } else if (f.id === "channel-form") {
        const name = text(d.name, 80);
        const c = {
          id: id("CH"),
          name:
            (d.kind === "Direct message"
              ? "Direct · "
              : d.kind === "Group"
                ? "Group · "
                : "") + name,
          private: d.kind !== "Departmental",
          workspace,
          project: d.project,
          contact: d.contact,
        };
        a.channels.push(c);
        channel = c.id;
      } else if (f.id === "message-form") {
        if (!a.channels.some((c) => c.id === channel))
          throw Error("Create or select a channel first.");
        a.messages.push({
          id: id("M"),
          channel,
          body: text(d.body, 2000),
          at: date(),
          attachment: attached,
          reactions: 0,
          pinned: false,
        });
      } else if (f.dataset.thread)
        a.messages.push({
          id: id("M"),
          parent: f.dataset.thread,
          channel,
          body: text(d.body, 1000),
          at: date(),
          reactions: 0,
        });
      else if (f.id === "workflow-form") {
        const steps = d.steps
          .split("\n")
          .filter((x) => x.trim())
          .map((l) => {
            const i = l.indexOf(":");
            const kind = l.slice(0, i).trim();
            if (
              i < 1 ||
              !["Call", "Email", "Condition", "Approval"].includes(kind)
            )
              throw Error("Use Kind: description for each workflow step.");
            return { kind, title: l.slice(i + 1).trim() };
          });
        A.workflow(s, { ...d, steps });
        mark(s, "flow");
      } else if (f.id === "project-form") {
        if (!d.deadline) throw Error("Choose a deadline.");
        a.projects.push({
          id: id("PR"),
          name: text(d.name, 100),
          deadline: d.deadline,
        });
      } else if (f.id === "task-form") {
        const old = editingTask && a.tasks.find((t) => t.id === editingTask.id);
        if (old) {
          const title = text(d.title);
          Object.assign(old, {
            title,
            contact: d.contact,
            opportunity: d.opportunity,
            project: d.project,
            assignee: text(d.assignee, 100),
            due: d.due || old.due,
          });
          if (old.approval !== (d.type === "Approval")) {
            old.approval = d.type === "Approval";
            old.status = old.approval ? "Pending approval" : "Open";
          }
          editingTask = null;
        } else A.task(s, { ...d, approval: d.type === "Approval" });
        mark(s, "task");
      } else if (f.id === "criteria-form") {
        for (const k of Object.keys(a.criteria))
          a.criteria[k] = integer(d[k], 0, 100);
        if (Object.values(a.criteria).reduce((n, v) => n + v, 0) === 0)
          throw Error("At least one weight must be positive.");
      } else if (f.id === "invoice-form") {
        const lines = [...f.querySelectorAll(".invoice-line")].map((l) => ({
          description: l.querySelector("[name=description]").value,
          quantity: l.querySelector("[name=quantity]").value,
          unit: l.querySelector("[name=unit]").value,
        }));
        A.invoice(s, { ...d, id: editingInvoice?.id, lines });
        editingInvoice = null;
        mark(s, "invoice");
      } else if (f.id === "payment-form") {
        const t = S.payment(s, d);
        if (t.status === "Approved") mark(s, "payment");
      } else if (f.id === "fees-form") S.fees(s, d.bps, d.fixed);
      else if (f.dataset.module) {
        const m = sh.modules.find((m) => m.id === f.dataset.module),
          limit = integer(d.limit);
        if (limit < m.spent)
          throw Error("Limit cannot be below current spending.");
        m.limit = limit;
      } else if (f.id === "benefit-form") {
        sh.benefit = integer(d.points, 0, 100);
        sh.merchant = text(d.merchant, 100);
        sh.benefitDescription = text(d.description, 200);
      } else throw Error("Unknown form.");
    });
    render();
    notice("Saved locally. No external service was contacted.");
  } catch (err) {
    notice(err.message);
  }
});
function updateInvoicePreview() {
  try {
    const lines = [...document.querySelectorAll(".invoice-line")].map((l) => ({
      quantity: integer(l.querySelector("[name=quantity]").value, 1, 10000),
      unit: integer(l.querySelector("[name=unit]").value, 0, 10000000),
    }));
    $("#invoice-preview").textContent = money(A.total({ lines }));
  } catch {
    $("#invoice-preview").textContent =
      "Enter valid quantities and integer cent prices.";
  }
}
$("#content").addEventListener("input", (e) => {
  if (e.target.id === "pipeline-search") {
    pipelineSearch = e.target.value;
    render();
  }
  if (
    ["contact-search", "message-search", "transaction-search"].includes(
      e.target.id,
    )
  ) {
    query = e.target.value;
    render();
  }
  if (e.target.closest("#invoice-form")) updateInvoicePreview();
});
$("#content").addEventListener("change", async (e) => {
  try {
    if (e.target.id === "pipeline-search") {
      pipelineSearch = e.target.value;
      render();
    }
    if (
      ["contact-search", "message-search", "transaction-search"].includes(
        e.target.id,
      )
    ) {
      query = e.target.value;
      render();
    }
    if (e.target.id === "document-upload") {
      const file = e.target.files[0];
      if (file) {
        if (file.size > 100000 || !/\.(txt|csv)$/i.test(file.name))
          throw Error("Use a fictional TXT or CSV under 100 KB.");
        $("#document-form textarea").value = await file.text();
      }
    }
    if (e.target.id === "workspace") {
      workspace = e.target.value;
      channel =
        store.state.ama.channels.find((c) => c.workspace === workspace)?.id ||
        "";
      render();
    }
    if (e.target.name === "template") {
      const templates = {
        Outreach:
          "Call: Introduce offer\nCondition: Customer has fictional email\nEmail: Follow up\nApproval: Review proposal",
        "Customer follow-up":
          "Email: Draft customer follow-up\nCall: Schedule callback",
        "Manager approval": "Approval: Review request",
      };
      e.target.form.elements.steps.value = templates[e.target.value];
    }
    if (e.target.id === "prospect-import") {
      const file = e.target.files[0];
      if (!file) return;
      if (file.size > 1000000) throw Error("Use a fictional CSV under 1 MB.");
      const rows = parseCSV(await file.text()),
        headers = rows.shift(),
        required = [
          "company",
          "name",
          "industry",
          "location",
          "size",
          "role",
          "email",
        ];
      if (required.some((h) => !headers.includes(h)))
        throw Error("CSV must include: " + required.join(", "));
      if (rows.length > 1000) throw Error("Maximum 1,000 records.");
      const records = rows.map((r) => {
        const p = Object.fromEntries(headers.map((h, i) => [h, r[i]]));
        for (const h of required.filter((h) => !["email", "size"].includes(h)))
          p[h] = text(p[h], 100);
        p.size = integer(p.size, 1, 1000000);
        if (p.email && !/^[^\s@]+@[^\s@]+\.example$/.test(p.email))
          throw Error("Use only fictional .example contact emails.");
        return {
          ...p,
          id: id("P"),
          signals: [],
          source: "Approved CSV",
          status: p.email ? "Fictional email available" : "No email",
        };
      });
      window.pendingProspects = records;
      notice("CSV validated. Confirm that every record is fictional below.");
      e.target
        .closest(".card")
        .insertAdjacentHTML(
          "beforeend",
          `<form id="import-confirm"><label><input name="fictional" type="checkbox" required> I confirm these ${records.length} records are fictional and approved for a public demonstration.</label><button>Import validated records</button></form>`,
        );
    }
  } catch (err) {
    notice(err.message);
  }
});
// Separate listener validates the explicit fictional-dataset confirmation before mutation.
$("#content").addEventListener("submit", (e) => {
  if (e.target.id !== "import-confirm") return;
  e.preventDefault();
  if (!e.target.elements.fictional.checked) return;
  try {
    change("prospects.imported", (s) =>
      s.ama.prospects.push(...(window.pendingProspects || [])),
    );
    window.pendingProspects = null;
    render();
    notice("Approved fictional records imported.");
  } catch (err) {
    notice(err.message);
  }
});
$("#theme").addEventListener("click", () => {
  change(
    "theme.changed",
    (s) => (s.theme = s.theme === "dark" ? "light" : "dark"),
  );
  render();
});
window.addEventListener("hashchange", () => {
  query = "";
  render();
  $("#content").focus();
});
render();
