import { id, date, text, integer } from "../core/store.js";
export const leadScore = (p) => ({
  score: Math.min(
    100,
    20 +
      (p.size >= 20 ? 20 : 0) +
      (["Director", "Founder", "Operations"].includes(p.role) ? 20 : 0) +
      Math.min(30, p.signals.length * 15) +
      (p.email ? 10 : 0),
  ),
  criteria:
    "20 base + 20 size ≥20 + 20 decision-maker role + 15 per signal (max 30) + 10 fictional contact available",
});
export const total = (i) =>
  i.lines.reduce((n, l) => n + l.quantity * l.unit, 0);
export const metrics = (s) => {
  const a = s.ama,
    open = a.opportunities.filter((o) => !["Won", "Lost"].includes(o.stage));
  return {
    pipeline: open.reduce((n, o) => n + o.value, 0),
    weighted: open.reduce(
      (n, o) => n + Math.round((o.value * o.probability) / 100),
      0,
    ),
    won: a.opportunities.filter((o) => o.stage === "Won").length,
    conversion: a.opportunities.length
      ? (a.opportunities.filter((o) => o.stage === "Won").length /
          a.opportunities.length) *
        100
      : 0,
    calls: a.calls.length,
    tasks: a.tasks.filter((t) => t.status !== "Done").length,
    invoiced: a.invoices.reduce((n, i) => n + total(i), 0),
    paid: a.invoices.reduce((n, i) => n + i.paid, 0),
    workflows: a.workflows.filter((w) => w.status === "Completed").length,
  };
};
export function account(s, data) {
  const name = text(data.name || data.company, 100);
  let a = data.accountId
    ? s.ama.accounts.find((a) => a.id === data.accountId)
    : s.ama.accounts.find((a) => a.name.toLowerCase() === name.toLowerCase());
  if (data.accountId && !a) throw Error("Account not found.");
  const values = {
    name,
    industry: text(data.industry || a?.industry || "Unspecified", 100),
    location: text(data.location || a?.location || "Unspecified", 100),
    size: integer(data.size ?? a?.size ?? 0, 0, 1000000),
  };
  if (a) {
    Object.assign(a, values);
    for (const c of s.ama.contacts.filter((c) => c.account === a.id))
      c.company = a.name;
  } else {
    s.ama.accounts.push((a = { id: id("ACCT"), ...values, created: date() }));
  }
  return a;
}
export function contact(s, data) {
  let c = data.id ? s.ama.contacts.find((c) => c.id === data.id) : null;
  const values = {
    name: text(data.name, 100),
    company: text(data.company, 100),
    email: String(data.email || "").trim(),
    role: text(data.role || "Contact", 80),
    lifecycle: ["Lead", "Qualified", "Customer"].includes(data.lifecycle)
      ? data.lifecycle
      : "Lead",
    archived: false,
  };
  if (values.email && !/^[^\s@]+@[^\s@]+\.example$/.test(values.email))
    throw Error("Use fictional .example email addresses only.");
  values.account = account(s, {
    company: values.company,
    industry: data.industry,
    location: data.location,
    size: data.size,
  }).id;
  if (c) Object.assign(c, values);
  else {
    s.ama.contacts.push(
      (c = {
        id: id("C"),
        ...values,
        source: data.source || "Manual fictional entry",
        created: date(),
      }),
    );
  }
  return c;
}
export function addProspect(s, pid) {
  const p = s.ama.prospects.find((x) => x.id === pid);
  if (!p) throw Error("Prospect not found.");
  const existing = s.ama.contacts.find((x) => x.prospectId === pid);
  if (existing) {
    existing.archived = false;
    return existing;
  }
  const c = contact(s, p);
  c.prospectId = pid;
  return c;
}
export function opportunity(s, d) {
  if (!s.ama.contacts.some((c) => c.id === d.contact && !c.archived))
    throw Error("Select an active customer.");
  if (!s.ama.stages.includes(d.stage)) throw Error("Unknown pipeline stage.");
  const o = {
    id: d.id || id("O"),
    contact: d.contact,
    name: text(d.name, 100),
    value: integer(d.value),
    probability: integer(d.probability, 0, 100),
    stage: d.stage,
    at: date(),
  };
  const old = s.ama.opportunities.find((x) => x.id === o.id);
  if (old) Object.assign(old, o);
  else s.ama.opportunities.push(o);
  if (o.stage === "Won")
    s.ama.contacts.find((c) => c.id === o.contact).lifecycle = "Customer";
  return o;
}
export function task(s, d) {
  const t = {
    id: id("T"),
    title: text(d.title),
    contact: d.contact || "",
    opportunity: d.opportunity || "",
    message: d.message || "",
    project: d.project || "PR-1",
    assignee: text(d.assignee || "Jordan Example", 100),
    due: d.due || new Date().toISOString().slice(0, 10),
    approval: !!d.approval,
    at: date(),
    status: d.approval ? "Pending approval" : "Open",
  };
  s.ama.tasks.push(t);
  return t;
}
export function call(s, action, data = {}) {
  let c = s.ama.activeCall;
  if (action === "start") {
    if (c) throw Error("Complete the active call first.");
    if (!s.ama.contacts.some((x) => x.id === data.contact))
      throw Error("Choose a CRM contact first.");
    s.ama.activeCall = {
      id: id("CALL"),
      contact: data.contact,
      direction: data.direction || "Outbound",
      number: text(data.number || "DEMO-100", 30),
      status: "Connecting",
      muted: false,
      participants: ["You"],
      timeline: [{ at: date(), text: "Connecting · simulation" }],
    };
    return;
  }
  if (!c) throw Error("Start a simulated call first.");
  if (action === "active") {
    if (c.status !== "Connecting") throw Error("Call is already connected.");
    c.status = "Active";
  } else if (action === "hold") {
    if (!["Active", "Hold"].includes(c.status)) throw Error("Connect first.");
    c.status = c.status === "Hold" ? "Active" : "Hold";
  } else if (action === "mute") {
    if (!["Active", "Hold"].includes(c.status))
      throw Error("Connect the call first.");
    c.muted = !c.muted;
  } else if (action === "participant") {
    if (!["Active", "Hold"].includes(c.status)) throw Error("Connect first.");
    const name = text(data.name, 100);
    if (!c.participants.includes(name)) c.participants.push(name);
  } else if (action === "transfer") {
    if (!["Active", "Hold"].includes(c.status))
      throw Error("Connect the call first.");
    c.transferredTo = text(data.name, 100);
    c.participants = [...new Set([...c.participants, c.transferredTo])];
  } else if (action === "end") {
    if (c.status === "Connecting")
      throw Error("Connect the simulated call first.");
    c.status = "Completed";
    c.at = date();
    c.transcript = [
      {
        speaker: "Customer",
        body: "How will onboarding work? Our concern is cost and approval time.",
      },
      {
        speaker: "You",
        body: "We can send a scoped quotation and schedule a review.",
      },
      {
        speaker: "Customer",
        body: "I commit to reviewing the quotation next Tuesday.",
      },
      {
        speaker: "You",
        body: "I will send the follow-up and confirm a callback tomorrow.",
      },
    ];
    s.ama.calls.push(c);
    s.ama.activeCall = null;
    return c;
  } else throw Error("Unknown call action.");
  c.timeline.push({
    at: date(),
    text: `${action}: ${c.status}${data.name ? " · " + data.name : ""}`,
  });
}
export function workflow(s, d) {
  if (!s.ama.contacts.some((c) => c.id === d.contact))
    throw Error("Choose a CRM contact.");
  const steps = d.steps || [
    { kind: "Call", title: "Introduce the fictional offer" },
    { kind: "Condition", title: "Proceed only if customer has an email" },
    { kind: "Email", title: "Draft follow-up" },
    { kind: "Approval", title: "Manager review" },
  ];
  if (!steps.length) throw Error("Add a workflow step.");
  const w = {
    id: id("FLOW"),
    name: text(d.name),
    contact: d.contact,
    assignee: d.assignee || "Jordan Example",
    scheduled: d.scheduled || "",
    steps: steps.map((x) => ({ kind: text(x.kind, 30), title: text(x.title) })),
    cursor: 0,
    status: "Ready",
    history: [],
  };
  s.ama.workflows.push(w);
  return w;
}
export function runWorkflow(s, w, action) {
  if (!w) throw Error("Workflow not found.");
  if (["Completed", "Cancelled"].includes(w.status))
    throw Error("Workflow is already finalized.");
  if (action === "cancel") {
    w.status = "Cancelled";
  } else if (action === "pause") {
    if (w.status !== "Running")
      throw Error("Only running workflows can pause.");
    w.status = "Paused";
  } else if (action === "resume") {
    if (!["Paused", "Waiting approval"].includes(w.status))
      throw Error("Workflow is not paused.");
    if (
      w.status === "Waiting approval" &&
      !s.ama.tasks.some(
        (t) => t.id === w.approvalTask && t.status === "Approved",
      )
    )
      throw Error("Approve the manager task first.");
    w.status = "Running";
  } else if (action === "execute") {
    if (
      ["Completed", "Cancelled", "Paused", "Waiting approval"].includes(
        w.status,
      )
    )
      throw Error("This workflow cannot advance in its current state.");
    if (w.scheduled && w.scheduled > new Date().toISOString().slice(0, 10))
      throw Error("Scheduled for a future date.");
    w.status = "Running";
    const step = w.steps[w.cursor];
    const c = s.ama.contacts.find((c) => c.id === w.contact);
    if (step.kind === "Condition" && !c.email) {
      w.status = "Cancelled";
      w.history.push({
        at: date(),
        text: "Condition failed: no approved fictional email",
      });
      return;
    }
    if (step.kind === "Approval") {
      w.approvalTask = task(s, {
        title: step.title,
        contact: w.contact,
        assignee: w.assignee,
        approval: true,
      }).id;
      w.status = "Waiting approval";
    } else if (step.kind !== "Condition")
      task(s, {
        title: `${step.kind}: ${step.title}`,
        contact: w.contact,
        assignee: w.assignee,
      });
    w.cursor++;
    if (w.cursor === w.steps.length && w.status !== "Waiting approval")
      w.status = "Completed";
  } else throw Error("Unknown workflow action.");
  if (w.cursor === w.steps.length && w.status === "Running")
    w.status = "Completed";
  w.history.push({
    at: date(),
    text: `${action} · ${w.status} · step ${w.cursor}/${w.steps.length}`,
  });
}
export function invoice(s, d) {
  if (!s.ama.contacts.some((c) => c.id === d.contact))
    throw Error("Select a customer.");
  const lines = d.lines.map((l) => ({
    description: text(l.description, 100),
    quantity: integer(l.quantity, 1, 10000),
    unit: integer(l.unit, 0, 10000000),
  }));
  if (!lines.length || lines.length > 50)
    throw Error("Use 1–50 invoice lines.");
  const old = s.ama.invoices.find((i) => i.id === d.id);
  if (
    old &&
    s.sharim.transactions.some(
      (t) => t.invoice === old.id && t.status === "Approved",
    )
  )
    throw Error("Refund the active payment before editing an invoice.");
  const value = lines.reduce((n, l) => n + l.quantity * l.unit, 0);
  integer(value, 1, 100000000);
  if (old) {
    Object.assign(old, { lines, status: "Unpaid", paid: 0 });
    return old;
  }
  const i = {
    id: id("INV"),
    contact: d.contact,
    opportunity: d.opportunity || "",
    lines,
    currency: "CAD",
    paid: 0,
    status: "Unpaid",
    at: date(),
  };
  s.ama.invoices.push(i);
  return i;
}
export function coach(c, criteria) {
  const lines = c?.transcript || [];
  const all = lines.map((l) => l.body).join(" ");
  const rules = [
    ["questions", /\?/, "Question is present"],
    ["objections", /concern|cost|approval/i, "Explicit objection recorded"],
    ["commitments", /commit|reviewing/i, "Customer commitment recorded"],
    ["followup", /follow-up|callback/i, "Follow-up or callback recorded"],
  ];
  const evidence = rules.map(([key, re, label]) => ({
    key,
    label,
    weight: criteria[key],
    pass: re.test(all),
    evidence:
      lines.find((l) => re.test(l.body))?.body ||
      "No matching transcript evidence.",
  }));
  const max = evidence.reduce((n, e) => n + e.weight, 0);
  return {
    score: max
      ? Math.round(
          (evidence.filter((e) => e.pass).reduce((n, e) => n + e.weight, 0) /
            max) *
            100,
        )
      : 0,
    evidence,
  };
}
export function intelligence(s, q) {
  q = q.toLowerCase();
  const m = metrics(s);
  const named = s.ama.contacts.filter(
    (c) =>
      q.includes(c.name.toLowerCase()) || q.includes(c.company.toLowerCase()),
  );
  if (named.length) {
    s = structuredClone(s);
    s.ama.contacts = named;
  }
  if (/pipeline|forecast|performance|prévision|prévisions/.test(q))
    return {
      answer: `Open pipeline CAD ${(m.pipeline / 100).toFixed(2)}; probability-weighted forecast CAD ${(m.weighted / 100).toFixed(2)}. Close or update opportunities to change this result.`,
      refs: s.ama.opportunities.map((o) => o.id),
    };
  if (/customer|summary|client|résumé/.test(q)) {
    return {
      answer:
        s.ama.contacts
          .map(
            (c) =>
              `${c.name} at ${c.company}: ${s.ama.opportunities.filter((o) => o.contact === c.id).length} opportunities, ${s.ama.tasks.filter((t) => t.contact === c.id && t.status !== "Done").length} outstanding tasks.`,
          )
          .join("\n") ||
        "No customers yet. Add a fictional prospect in Discover.",
      refs: s.ama.contacts.map((c) => c.id),
    };
  }
  if (/invoice|payment|facture|paiement/.test(q))
    return {
      answer: `Invoice total CAD ${(m.invoiced / 100).toFixed(2)}; received CAD ${(m.paid / 100).toFixed(2)}; outstanding CAD ${((m.invoiced - m.paid) / 100).toFixed(2)}. Fictional records only.`,
      refs: s.ama.invoices.map((i) => i.id),
    };
  if (/call|conversation|appel/.test(q))
    return {
      answer: `${m.calls} completed simulated calls. ${s.ama.calls.map((c) => c.transcript?.map((l) => l.body).join(" ")).join("\n") || "Complete a simulation to create a labelled sample transcript."}`,
      refs: s.ama.calls.map((c) => c.id),
    };
  if (/draft|follow|email|rédig/.test(q))
    return {
      answer:
        "Demonstration draft: Thank you for reviewing our fictional proposal. Please confirm your preferred review time and any outstanding requirements. No message has been sent.",
      refs: s.ama.calls.map((c) => c.id),
    };
  if (/workflow|recommend|suggest|task/.test(q))
    return {
      answer: `Rule: follow up on open tasks before creating more outreach. ${m.tasks} tasks remain open. Use manager approval before advancing a quotation.`,
      refs: s.ama.tasks.map((t) => t.id),
    };
  return {
    answer:
      "Deterministic assistance: supported queries are pipeline forecast, customer summary, follow-up draft and workflow recommendations. Technical preview: secure model integration requires a server adapter. English and French query keywords are supported; translation is not implemented.",
    refs: [],
  };
}
