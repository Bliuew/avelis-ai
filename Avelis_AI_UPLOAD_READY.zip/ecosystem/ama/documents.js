/** Local text inspection with verbatim evidence, never model-generated analysis. */
export function inspectDocument(value) {
  const text = String(value || "").trim();
  if (!text) throw Error("Enter or upload fictional text.");
  if (text.length > 100000)
    throw Error("Use a document under 100,000 characters.");
  const lines = text.split(/\r?\n/).map((body, i) => ({ line: i + 1, body }));
  const terms = [
    "follow-up",
    "callback",
    "cost",
    "approval",
    "deadline",
    "quotation",
  ];
  return {
    words: text.split(/\s+/).length,
    characters: text.length,
    lines: lines.length,
    evidence: terms.map((term) => ({
      term,
      matches: lines.filter((l) => l.body.toLowerCase().includes(term)),
    })),
  };
}
export async function attachment(file) {
  if (!file || !file.name) return null;
  if (file.size > 500000)
    throw Error("Use a fictional attachment under 500 KB.");
  if (!/\.(txt|csv|pdf|png|jpe?g)$/i.test(file.name))
    throw Error("Supported demo attachments: TXT, CSV, PDF, PNG and JPEG.");
  const bytes = new Uint8Array(await file.arrayBuffer());
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return {
    name: file.name,
    size: file.size,
    type: file.type || "application/octet-stream",
    base64: btoa(binary),
  };
}
export function attachmentBytes(file) {
  if (!file?.base64) throw Error("Attachment contents are unavailable.");
  return Uint8Array.from(atob(file.base64), (c) => c.charCodeAt(0));
}
