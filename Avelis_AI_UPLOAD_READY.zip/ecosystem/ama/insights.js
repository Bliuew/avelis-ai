import { metrics, total } from "./domain.js";
/** Calculate every chart from a consistent, filtered snapshot of demonstration records. */
export function snapshot(
  state,
  { from = "", to = "", stage = "", source = "" } = {},
) {
  const s = structuredClone(state);
  const inRange = (x) =>
    (!from || (x.at || x.created || "").slice(0, 10) >= from) &&
    (!to || (x.at || x.created || "").slice(0, 10) <= to);
  const contactIds = new Set(
    s.ama.contacts
      .filter((c) => !source || c.source === source)
      .map((c) => c.id),
  );
  s.ama.contacts = s.ama.contacts.filter((c) => contactIds.has(c.id));
  s.ama.opportunities = s.ama.opportunities.filter(
    (o) =>
      inRange(o) && contactIds.has(o.contact) && (!stage || o.stage === stage),
  );
  const related = new Set(s.ama.opportunities.map((o) => o.id));
  s.ama.invoices = s.ama.invoices.filter(
    (i) =>
      inRange(i) &&
      contactIds.has(i.contact) &&
      (!stage || related.has(i.opportunity)),
  );
  const invoices = new Set(s.ama.invoices.map((i) => i.id));
  s.sharim.transactions = s.sharim.transactions.filter(
    (t) =>
      inRange(t) &&
      contactIds.has(t.contact) &&
      (!stage || invoices.has(t.invoice)),
  );
  s.ama.calls = s.ama.calls.filter(
    (c) => inRange(c) && contactIds.has(c.contact),
  );
  s.ama.tasks = s.ama.tasks.filter(
    (t) => !t.contact || contactIds.has(t.contact),
  );
  s.ama.workflows = s.ama.workflows.filter((w) => contactIds.has(w.contact));
  const count = (items, key) =>
    Object.entries(
      items.reduce((a, x) => {
        const k = x[key] || "Unspecified";
        a[k] = (a[k] || 0) + 1;
        return a;
      }, {}),
    );
  return {
    state: s,
    metrics: metrics(s),
    charts: {
      pipeline: s.ama.stages.map((stage) => [
        stage,
        s.ama.opportunities
          .filter((o) => o.stage === stage)
          .reduce((n, o) => n + o.value, 0),
      ]),
      sources: count(s.ama.contacts, "source"),
      calls: count(s.ama.calls, "direction"),
      tasks: count(s.ama.tasks, "status"),
      workflows: count(s.ama.workflows, "status"),
      invoices: ["Unpaid", "Paid", "Refunded"].map((status) => [
        status,
        s.ama.invoices
          .filter((i) => i.status === status)
          .reduce((n, i) => n + total(i), 0),
      ]),
      payments: ["Approved", "Declined", "Refunded"].map((status) => [
        status,
        s.sharim.transactions
          .filter((t) => t.status === status)
          .reduce((n, t) => n + t.amount, 0),
      ]),
    },
  };
}
