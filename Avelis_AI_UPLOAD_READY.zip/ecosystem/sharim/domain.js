import { id, date, integer, text } from "../core/store.js";
import { total } from "../ama/domain.js";
export function payment(s, d) {
  if (!s.sharim.connected)
    throw Error("Connect the optional Sharim sandbox first.");
  if (!s.sharim.permissions)
    throw Error("Sandbox spending permission is disabled.");
  const key = text(d.key, 120);
  const previous = s.sharim.transactions.find((t) => t.key === key);
  if (previous) {
    if (
      previous.invoice !== d.invoice ||
      previous.module !== d.module ||
      previous.requestedStatus !== d.status
    )
      throw Error(
        "This idempotency key belongs to a different request. Use the original request or a new key.",
      );
    return previous;
  }
  const i = s.ama.invoices.find((i) => i.id === d.invoice);
  if (!i) throw Error("Invoice not found.");
  if (i.paid > 0) throw Error("This invoice already has an approved payment.");
  if (!["Approved", "Declined"].includes(d.status))
    throw Error("Invalid transaction state.");
  const module = s.sharim.modules.find((m) => m.id === d.module);
  if (!module) throw Error("Choose a card module.");
  if (s.sharim.mode === "connected" && !module.attached)
    throw Error("Assemble this module or switch to individual-module mode.");
  const amount = total(i);
  if (
    d.status === "Approved" &&
    (module.frozen || module.spent + amount > module.limit)
  )
    throw Error("Module frozen or spending limit exceeded.");
  const fee =
    Math.round((amount * s.sharim.feeBps) / 10000) + s.sharim.fixedFee;
  if (fee > amount) throw Error("Fee exceeds payment amount.");
  const t = {
    id: id("TX"),
    key,
    invoice: i.id,
    contact: i.contact,
    module: module.id,
    amount,
    status: d.status,
    requestedStatus: d.status,
    fee: d.status === "Approved" ? fee : 0,
    points:
      d.status === "Approved"
        ? Math.floor((amount / 100) * s.sharim.benefit)
        : 0,
    at: date(),
  };
  s.sharim.transactions.push(t);
  if (s.sharim.alerts)
    s.sharim.notifications.push({
      id: id("ALERT"),
      at: date(),
      text: `${t.status} fictional transaction ${t.id} · CAD ${(t.amount / 100).toFixed(2)}`,
    });
  if (t.status === "Approved") {
    i.paid = amount;
    i.status = "Paid";
    module.spent += amount;
  }
  return t;
}
export function refund(s, tid) {
  if (!s.sharim.connected) throw Error("Connect Sharim to simulate a refund.");
  const t = s.sharim.transactions.find((x) => x.id === tid);
  if (!t || t.status !== "Approved")
    throw Error("Only an approved transaction can be refunded once.");
  t.status = "Refunded";
  t.refundedAt = date();
  t.points = 0;
  const i = s.ama.invoices.find((i) => i.id === t.invoice);
  i.paid -= t.amount;
  i.status = "Refunded";
  s.sharim.modules.find((m) => m.id === t.module).spent -= t.amount;
  t.originalFee = t.fee;
  t.fee = 0;
  if (s.sharim.alerts)
    s.sharim.notifications.push({
      id: id("ALERT"),
      at: date(),
      text: `Refunded fictional transaction ${t.id}`,
    });
  return t;
}
export const settlement = (s) =>
  s.sharim.transactions
    .filter((t) => t.status === "Approved")
    .reduce((n, t) => n + t.amount - t.fee, 0);
export function fees(s, bps, fixed) {
  s.sharim.feeBps = integer(bps, 0, 1000);
  s.sharim.fixedFee = integer(fixed, 0, 1000);
}
