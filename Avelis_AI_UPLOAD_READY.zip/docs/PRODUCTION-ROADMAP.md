# Production-readiness roadmap

The delivered application is a functional single-browser demonstration, not a secure production enterprise service.

## Before public investor release

- Complete actual browser QA at desktop/tablet/mobile sizes, keyboard-only navigation, screen-reader labels, focus restoration, contrast and light/dark themes.
- Review the integrated founder-approved exact artwork crops and provenance manifest before public release; retain exclusion of specifications and personal-looking details.
- Review all public content, fictional record labels and legal ownership statements with the founder.
- Review source and merge the feature branch only after acceptance. Publish through the existing GitHub Pages deployment.

## Secure application foundation

- Introduce real identity and session management, tenant-scoped database constraints, role policies and server-side validation.
- Add migrations, backups, retention/deletion controls, concurrency control and durable server-side event outbox processing.
- Move idempotency constraints, invoice/transaction state invariants and financial journals into database transactions. Support partial payments/refunds and currency-specific rounding only after dedicated accounting tests.
- Replace editable local audit with access-controlled append-only server events and documented retention.
- Implement production monitoring, error reporting, rate limits, secure headers, dependency checks and incident response.

## Service integrations

- AI: authenticated server inference adapter, scoped record retrieval, explicit evidence, consent, evaluation and multilingual quality review; keep keys on the server.
- Communication: authorized telephone provider, call-consent policies, recording retention, provider webhook validation, actual call lifecycle and access-controlled recordings.
- Messaging: authenticated real-time delivery, tenant authorization, notifications and secure attachment storage/scanning.
- Sharim: separate service ownership, licensed/authorized provider relationships where applicable, signed webhooks, server idempotency, reconciliation and independently validated financial controls. No licensing or certification is assumed.
- Reviewer portal: deploy and independently test the existing configured backend flow before enabling private submissions. Never implement browser-only pretend authentication.

## Product separation

Keep Amā domain services independent of the Avelis shell. Evolve the versioned integration boundary and publish schemas before independent deployment/corporation rollout. Keep Sharim optional through a capability adapter and preserve provider-independent commerce records. Define data processing/ownership contracts between Maarah and the Ditheka ecosystem before any real integration.

The physical modular card remains an unvalidated engineering concept. Hardware feasibility, intellectual-property handling and certification require separate confidential engineering work; none is established by Card Studio.
