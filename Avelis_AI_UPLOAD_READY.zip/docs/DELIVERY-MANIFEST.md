# Delivered upload package

The ZIP is the website project itself, with `index.html` at its top level. It is not a link to a hosted replacement and contains no deployment action or credentials.

| Path | Contents |
| --- | --- |
| `index.html` | Original Avelis site extended with connected application entry points and narrow integration ports |
| `ecosystem/index.html` | Investor Experience Centre, Amā and Sharim application shell |
| `ecosystem/app.js` | All 15 routes, forms and connected interaction handlers |
| `ecosystem/ama/` | CRM, calls, tasks, workflows, invoices, scoring, rule-based assistant, coaching, calculated insights and document/attachment logic |
| `ecosystem/sharim/` | Optional payment simulation, fee/reward effects, idempotency, refund and settlement logic |
| `ecosystem/core/` | Versioned store/events, CSV, future backend adapters and printable reports |
| `ecosystem/assets/` | Original logos and approved exact artwork crops; provenance manifest |
| `ecosystem/appearance.*` | Optional appearance controls for the preserved original site |
| `ecosystem/bridge.js` | Advisor data import and idempotent Avelis audit import |
| `ecosystem/tests/` | Domain, preservation, packaging and DOM integration tests |
| `samples/` | Supplied transaction CSV and approved fictional prospect CSV |
| `backups/` | Original public main entry point and main Git history bundle |
| `docs/` | Architecture, deployment, functionality/test disclosure, production roadmap and this manifest |
| `README.md`, `START-HERE.txt` | Setup, navigation and self-upload instructions |
| Existing original ZIPs/setup guide | Retained byte-for-byte from the original repository |

All executable source, styles and assets are included; there is no npm build step required to upload or run on GitHub Pages. The new application uses native ES modules, so preview it through HTTP rather than opening its HTML with a `file://` URL.

The feature branch is local. The founder controls upload, review, merge and publishing. Actual external service functionality remains intentionally simulated as disclosed throughout the public application.
