# Test results — completed source delivery, 17 November 2026

Original source base: `f097148f462f3d9cec67efd33765d7b1286d0b56`, the latest main fetched at task start and rechecked during the initial implementation. All subsequent work was local. This delivery is for the founder to upload; nothing was pushed or published.

## Executed results

- `npm test`: **31 passed, 0 failed** — domain invariants, preservation, backend adapter, financial calculations, document/attachment processing, HTML report escaping and package-resource checks.
- `node ecosystem/tests/dom-qa.mjs` with jsdom installed outside the project: **37 passed, 0 failed** — original and new application event-handler tests, navigation, forms, state transitions and download initiation.
- JavaScript syntax checks: passed for all delivered JavaScript modules and test files.
- Card artwork: original founder-approved exact crops included, with coordinates and output SHA-256 hashes in `ecosystem/assets/ARTWORK-PROVENANCE.json`. The full specification sheet is excluded.
- Actual browser preview startup: **failed at environment level**, `listen EPERM 127.0.0.1:4173`. Desktop/mobile visual layout, actual browser file saving, assistive-technology behavior and browser compatibility therefore remain **unverified**. DOM testing does not establish these results.

No application assertions remained failed after the final fixes. One additional integration test found that reset retained a deleted channel selection; reset now restores the default channel and clears transient filters/editors.

## Mandatory acceptance mapping

| Acceptance item | Result and evidence |
| --- | --- |
| Original website sections remain functional | Passed preservation and DOM regression checks: all original IDs and panels; integration creation, approval and sandbox test; incident generation/acknowledgment; specialists and assistant; pricing calculator; report exports and original reset. Actual browser visual regression remains unverified. |
| Advisor accepts CSV and calculates accurately | Passed actual file-input handler with the supplied `DEMO-1,Approved,500.00` record. Numeric result CAD 500; both original CSV/HTML report handlers initiate downloads. |
| Contacts create/edit | Passed forms and domain checks, including archive/restore, prospect deduplication, .example address restrictions and safe HTML rendering. |
| Opportunity forecasts update | Passed: 50,000 cents × 60% = 30,000 cents; edits recalculate; Won/Lost exclusion; won conversion calculated from actual records. |
| Calls support participant management | Passed: Connecting, Active, Hold, mute, conference participant, transfer and Completed; inbound queue add/answer/remove; labelled sample transcript. |
| Messages post and convert into tasks | Passed: posting, replies, group-channel creation, stable message reference, linked project/customer inheritance and task/approval creation. |
| Workflow execution states | Passed: conditional email gate, tasks, scheduled-date guard, pause/resume, manager approval gate and completion. |
| Invoices recalculate quantities/prices | Passed live preview and saved integer-cent calculations; invalid fractional cents rejected; paid invoice editing guarded until refund. |
| Payments update records | Passed: approval updates linked invoice, transaction, card spend, rewards and settlement; declined records leave invoice unpaid. |
| Duplicate transactions prevented | Passed: identical key/payload returns existing result; key/payload conflict rejected; another key cannot repay a paid invoice. |
| Refunds recalculate finances | Passed: invoice receipt, module spend, points and fee reversed; original fee retained; repeated refund rejected. |
| Sharim disconnect preserves Amā | Passed: independent CRM/opportunity/commerce remain usable; payment/refund execution requires a connection. |
| Card modules assemble/detach | Passed state controls, connected/individual modes, freezing and limit guards. Original cropped assembly and four module art resources present with verified hashes. |
| Advisor analyzes generated data | Passed original calculation path: approved CAD 500, fee CAD 12.80, net CAD 487.20; refunded current receipt becomes zero. |
| Reports download | Passed original reports and new investor HTML/JSON, invoice HTML, quotation HTML, transaction receipt HTML, transaction CSV, insight CSV, prospect CSV and local attachment download handlers. Actual browser save dialogs/filesystem remain unverified. |
| Persistence/reset | Passed storage reload, rollback, quota warning, progress and explicit reset; original Avelis namespace preserved; ecosystem Advisor handoff cleared by reset. |
| Mobile/desktop layouts | Responsive layouts, overflow handling, menu breakpoints and reduced-motion rules implemented. **Actual visual browser testing remains unverified** because preview could not start. |
| Original logos/branding unchanged | Original Avelis/Ditheka image tags and original archives are byte-identical. Amā/Sharim logos copied directly; card artwork cropped exactly under explicit founder approval. |
| No decorative buttons | Every introduced button, form and selector is wired to application logic, navigation or a defined error/disabled state. Main and secondary actions exercised in DOM. Exhaustive visual/keyboard/browser testing remains unverified. |

## Additional checks

- Stable account profiles, contact grouping, synchronized account renaming and deterministic migration of older records.
- Consistent date/stage/source filtering for metrics, seven chart groups and CSV export.
- Quotation snapshots, downloadable quotation, acceptance and order fulfillment/cancellation.
- Inbound call queues and assignment editing with follow-up dates.
- Original Avelis light/dark control; theme control in Amā and Sharim.
- English/French deterministic forecast and follow-up responses; documented supported query categories.
- Local document inspection with explicit line-number evidence.
- Exact local attachment byte round-trip, download, extension/size rejection and reset behavior.
- Configurable merchant rewards and generated local transaction alerts.
- Unconfigured backend fails closed; optional HTTPS session/CSRF transport rejects unsafe origins and requires model provenance/evidence. Tests use a fake server response; no production backend was contacted or certified.
- Original section IDs, logos, source archives, pilot placeholders and storage namespace preserved.
- Static asset paths, backup checksum, sample CSV and artwork checksums validated.

## Intentional public-prototype boundaries

These follow the requested browser-only demonstration architecture:

- All business records are fictional. No real contact enrichment, money movement, telephone call, model inference or multi-user delivery occurs.
- Browser storage is editable and not confidential or multi-tenant. Cross-tab concurrent editing is not guaranteed. Storage failures show an in-memory warning; reports can still be exported.
- Call transcripts are labelled fictional samples; coaching uses configurable text criteria and evidence, not personality/emotion inference.
- Intelligence uses documented deterministic query categories. French support covers forecast/follow-up templates; other responses retain explicit rule-based evidence. It is not a general translator or model.
- Document inspection accepts text/CSV; Link attachments accept supported files under 500 KB. Attachments stay local and are downloadable, with no malware scanning or secure document service.
- Workflows create local tasks and wait for explicit investor execution after a scheduled date. No background scheduler or actual outreach delivery is claimed.
- Commerce supports full-invoice payments/refunds in CAD, not tax compliance, partial settlement, exchange rates or a double-entry ledger. Fees and benefit changes apply prospectively.
- Card Studio represents the original concept and virtual controls; hardware feasibility, terminal compatibility and certification are unvalidated. Sensitive specifications and personal-looking card details are excluded.
- Advisor’s connected dataset shows current approved receipts; declined/refunded rows have zero receipt contribution. Transaction history retains the original gross amount and status.
- Local Avelis event import occurs on opening its page, with the existing bounded audit history. No certified/server-side audit is claimed.
- Private reviewer/pilot registration remains disabled until its secure backend is configured. No fake authentication or confidential reviewer storage was added.

## Browser follow-up checklist

Before merging/publishing, inspect actual desktop (1440px), tablet (768px) and mobile (390px) layouts; keyboard focus, screen-reader controls, light/dark contrast, table scrolling, real download saving, attachment handling and secondary actions. This is the outstanding environment-dependent validation, not an assertion of production readiness.
