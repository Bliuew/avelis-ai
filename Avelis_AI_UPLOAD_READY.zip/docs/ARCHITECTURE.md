# Architecture and integration interface

## Preservation strategy

The root `index.html` remains the original application, styles, branding and local storage key `avelis-connected-demo-v1`. Additions comprise a connected ecosystem section, one navigation link, two narrow internal integration ports and `ecosystem/bridge.js`. Original pilot backend placeholders and secure reviewer gating are untouched. No replacement framework or backend is introduced.

## Module boundaries

| Module | Responsibility |
| --- | --- |
| `core/store.js` | Seed data, transactional changes with rollback, persistence, versioned event envelopes, safe CSV exports, downloads |
| `ama/domain.js` | Prospect scoring, contacts, opportunities, forecast calculations, tasks, calls, workflows, invoices, deterministic assistant and coaching |
| `sharim/domain.js` | Optional payment simulation, fees, idempotency, refunds, settlement |
| `core/adapters.js` | Explicit unconfigured server-service boundary and Advisor dataset contract |
| `ama/insights.js` / `ama/documents.js` | Filter-consistent charts and reporting, evidence-referenced local document inspection and local attachment handling |
| `core/reports.js` | Escaped, printable HTML investor reports, invoices, quotations and receipts |
| `appearance.js` / `appearance.css` | Optional light/dark appearance for the preserved Avelis page |
| `app.js` / `style.css` | Accessible application shell, hash routes, forms, actions and branded responsive layouts |
| `bridge.js` | Validated import into original Advisor and idempotent Avelis audit import |

Amā and Sharim maintain isolated object namespaces in a single versioned persistence envelope (`avelis-ecosystem-v1`). A shared envelope deliberately keeps cross-product updates atomic in a single browser write: an invoice payment and its transaction never persist separately. Domain logic is independent of DOM rendering. The namespace boundary can become a service boundary later; the current implementation does not offer distributed transactions or cross-tab concurrency guarantees.

### Stable identifiers and relationships

Created records use prefixed UUIDs. Accounts have stable IDs and editable industry/location/size profiles. Contacts reference accounts and prospect IDs; opportunities reference contacts; calls reference contacts; tasks reference messages, contacts, opportunities and projects; workflows reference contacts and approval tasks; invoices reference contacts and opportunities; transactions reference invoices, contacts and module IDs. Quotation/order snapshots reference invoices. Channel metadata can link a customer and project and pass these links to message-derived tasks.

## Version 1 event contract

```json
{
  "id": "EV-uuid",
  "version": "1.0",
  "type": "payment-form",
  "at": "ISO-8601 UTC",
  "actor": "fictional-reviewer",
  "detail": {
    "records": [
      {"namespace":"ama","collection":"invoices","id":"INV-uuid"},
      {"namespace":"sharim","collection":"transactions","id":"TX-uuid"}
    ]
  }
}
```

Only internal UI/domain operations invoke changes. Every successful change appends an event with changed record IDs and rolls back in-memory state on validation failure. Events are browser-editable and do not constitute security evidence or actual authorization. Production service adapters must enforce authorization server-side. Avelis imports event IDs once (bounded to the most recent 2,000 known IDs) and retains its original 75-entry audit limit.

The bridge runs on opening the root page. It does not create a live cross-tab connection. Reset clears the ecosystem envelope, leaving the original Avelis history intact. Ecosystem reset does not erase historical events already imported into Avelis.

## Advisor dataset contract

`advisorDataset(state)` returns version `1.0`, headers, rows, source, sample flag, metric and group. Columns: `date,transaction,status,amount_cad,fee_cad,net_cad`. Only currently approved transactions contribute nonzero approved amount/net; declined/refunded rows contribute zero. Original gross transaction amounts remain in merchant reports. This is a current-state cash-receipt dataset, not an accrual ledger or time-series accounting journal.

The dataset is stored at `avelis-ecosystem-advisor-v1`. The Send to Advisor action opens the original page with `?ecosystem=advisor#advisor-preview`. `AvelisAdvisorImport` validates the envelope/row shapes and calls the original `loadData` and `run` calculation path. Existing CSV upload and downloads remain unchanged. `AvelisEcosystemAudit` imports versioned events with ID deduplication. Neither port fetches external resources.

## Financial invariants

- Values, quantities, probabilities and limits are validated with safe integer bounds.
- Money is CAD integer cents. Invoice line total = quantity × unit cents. Maximum invoice total CAD 1,000,000.
- Weighted forecast = sum of each open opportunity's rounded value × probability/100. Won/Lost excluded.
- Transaction statuses: Approved, Declined, Refunded. Only Approved may transition to Refunded, once.
- Same idempotency key and request payload returns the existing transaction. A changed payload using the same key is rejected. Another key cannot pay an already-paid invoice.
- An approved invoice cannot be edited until refunded. Refund reverses paid balance, module spend, points and demo fee.
- Fees = rounded amount × basis points/10,000 + fixed cents. Future settings never rewrite previous transactions.
- Only connected Sharim may process or refund. Frozen modules, spending permissions and limits are enforced. Connected-card mode requires the selected module to be assembled.
- Individual-module mode permits detached modules. No card credentials or real account identifiers are accepted.

## Threat model and limitations

Escaped text rendering, input bounds, restricted fictional email domains, CSV formula neutralization and no client secrets reduce common public-demo risks. These are not a security certification. Browser storage and exported reports are public demo material and can be read or modified by the visitor. Do not input confidential data. Storage failure keeps records in memory and displays an explicit warning.

No authentication or fabricated reviewer login exists. No application record is a private reviewer record. The existing private reviewer link remains disabled until its secure backend is configured. Original site external font imports are retained.

Future `BackendAdapter` services: authentication, tenancy, permissions, AI, messaging, telephony, payments, audit. `BackendAdapter` remains an explicitly unconfigured demonstration stub. Optional `ServerAdapter` is disabled by default; it validates an HTTPS origin, uses HttpOnly-cookie sessions with a server-issued CSRF token, bounds request size, validates response versions and requires model provenance/evidence for AI output. It never requires an API key in the browser. The server must authenticate, authorize tenant-scoped actions, enforce CSRF/CORS and hold provider credentials. Adding a URL alone is insufficient.

## Artwork handling

Card Studio’s assembly and individual module images are pixel-exact crops of the founder-supplied concept sheet, explicitly approved in this conversation. Only the non-sensitive front/module artwork is included. No personal-looking card details, specification panel or infrastructure claims are shipped. The full original sheet remains outside the public project.

## Local attachments and privacy

Link accepts fictional TXT, CSV, PDF, PNG and JPEG files under 500 KB, retains their exact bytes in local browser storage, and offers an explicit download. Files are never rendered as HTML or transmitted. Reset removes the local records and attachments. The public demo does not provide malware scanning or confidential storage. Document analysis separately accepts TXT/CSV text under 100 KB and reports verbatim line evidence; it does not use a model.
