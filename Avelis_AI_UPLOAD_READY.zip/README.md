# Avelis AI — connected enterprise ecosystem

Functional browser-local prototype extending the latest `main` snapshot `f097148` (17 November 2026). The original single-page Avelis application remains at `index.html`; the new investor applications start at `ecosystem/index.html#investor`. No build step or production service is required for GitHub Pages.

**Review branch:** `feature/connected-enterprise-ecosystem`. Do not publish until reviewed. This project does not provide production authentication, telecommunications, payments or AI inference.

## Run

Serve the repository root with any static HTTP server, for example `python3 -m http.server 8000`, then open `/ecosystem/index.html#investor`. ES modules require HTTP rather than a `file://` URL. Existing GitHub Pages branch/root deployment remains compatible; all assets use relative URLs.

## Explore the connected journey

1. Discover → search Cedar → Add to CRM → Add to outreach.
2. Relations → create a CAD 50,000-cent opportunity with a probability; inspect the calculated weighted forecast.
3. Flow → execute steps; pause/resume; approve manager tasks in Teams before continuing.
4. Connect → select customer → start simulation → connect → add colleague → hold/mute/transfer → complete.
5. Coach → inspect sample transcript and scoring evidence; Link → post message → reply → convert to task or approval.
6. Relations → edit opportunity to Won. Commerce → create invoice; quantities and unit prices use integer CAD cents.
7. Merchant sandbox → connect optional Sharim → approve a fictional payment. Inspect invoice history, fees, reconciliation and transaction receipt.
8. Insights → send generated dataset to Advisor. The original Advisor loads and calculates the actual transaction values. Avelis imports versioned ecosystem events into its local audit.
9. Return to Experience Centre → download report. Refunds reverse the invoice receipt, module spend, reward points and settlement calculation. Disconnect Sharim to continue independently in Amā.

## Included

- Original Command Centre, Business and Developer Workspaces, integrations, approvals, incidents, specialists, assistant preview, pricing, audit, pilot and reviewer configuration.
- Original Advisor CSV parsing, calculations, charts and report exports, plus a validated ecosystem data port.
- Amā Discover, Relations, Connect, Link, Flow, Intelligence, Coach, Teams, Insights and Commerce.
- Sharim Merchant Sandbox, virtual module controls, Rewards and Security.
- Persistent guided/independent investor modes, explicit reset, light/dark theme, escaped user content, semantic forms and keyboard focus styles.

All seeded companies, contacts, activities and financial records are fictional. User-created demonstration records must also be fictional. Messaging is local, supported fictional attachments stay in local browser storage and can be downloaded, calls use a labelled sample transcript, intelligence uses fixed rules, and financial transactions move no money.

## Tests

`npm test` runs 31 dependency-free domain, preservation and packaging tests. Optional DOM integration QA: install `jsdom` in an external QA directory and run `JSDOM_PATH=/absolute/path/to/jsdom/lib/api.js node ecosystem/tests/dom-qa.mjs`. See [test results](docs/TEST-RESULTS.md) for the 37 DOM checks, unverified browser layout, and remaining acceptance gaps.

## Branding and ownership

Kubézema → Umoja Network → Ditheka Intelligence → Avelis AI and Amā. Avelis AI is the immediate priority; Amā starts as an integrated experience with planned later independent incorporation. Sharim is under Maarah and remains a detachable integration.

The original embedded Avelis and Ditheka images are unchanged. The supplied Amā and Sharim logo JPEGs are copied byte-for-byte. With the founder’s explicit permission, Card Studio uses exact crops of the supplied original artwork. The specification panel, personal-looking details and unsupported infrastructure claims are excluded. Crop coordinates and checksums are recorded in `ecosystem/assets/ARTWORK-PROVENANCE.json`; no artwork was redrawn.

## Documentation

- [Architecture and integration contract](docs/ARCHITECTURE.md)
- [Deployment and review handoff](docs/DEPLOYMENT.md)
- [Acceptance results and limitations](docs/TEST-RESULTS.md)
- [Production-readiness roadmap](docs/PRODUCTION-ROADMAP.md)

The original source ZIPs in main are retained unchanged. `backups/original-main-index.html` is a byte-identical backup of the original public entry point. The current upload ZIP contains the project directly at its top level; see `START-HERE.txt`. Nothing has been pushed or published.
