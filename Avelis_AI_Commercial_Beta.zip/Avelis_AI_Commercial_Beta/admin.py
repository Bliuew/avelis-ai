"""Local operator utilities. Run only in a trusted server shell. Never expose publicly."""
import argparse,csv,sys
from server import db,digest,safe_csv
p=argparse.ArgumentParser();p.add_argument('command',choices=['leads','members','disable-member','remove-lead']);p.add_argument('--email');p.add_argument('--confirm',action='store_true');a=p.parse_args()
with db() as c:
 if a.command=='leads':
  w=csv.writer(sys.stdout);w.writerow(['email','name','company','created_epoch']);w.writerows([safe_csv(v) for v in r] for r in c.execute('SELECT email,name,company,created FROM leads ORDER BY created DESC'))
 elif a.command=='members':
  for r in c.execute('SELECT users.email,users.role,orgs.name FROM users JOIN orgs ON users.org=orgs.id'):print(*r,sep=' | ')
 elif a.command=='remove-lead':
  if not(a.confirm and a.email):p.error('Require --email and --confirm')
  c.execute('DELETE FROM leads WHERE email=?',(a.email.lower(),));print('Lead record removed if present.')
 else:
  if not(a.confirm and a.email):p.error('Require --email and --confirm')
  u=c.execute('SELECT id,role FROM users WHERE email=?',(a.email.lower(),)).fetchone()
  if not u or u['role']=='owner':p.error('Member not found or is owner; owner management requires controlled migration.')
  # Keep a tombstone to prevent re-registration of the same email and revoke existing sessions.
  import secrets
  from server import hashpw
  c.execute('DELETE FROM sessions WHERE uid=?',(u['id'],));c.execute('UPDATE users SET pw=?,role=? WHERE id=?',(hashpw(secrets.token_urlsafe(48)),'disabled',u['id']));print('Member access disabled; records retained.')
