import os,sys,subprocess,tempfile,time,pathlib,urllib.request,requests,re,base64,mimetypes
from playwright.sync_api import sync_playwright
root=pathlib.Path(__file__).resolve().parents[1];tmp=tempfile.TemporaryDirectory();env=dict(os.environ,AVELIS_DB=str(pathlib.Path(tmp.name)/'browser.db'),AVELIS_ORIGIN='http://127.0.0.1:8768',AVELIS_BETA_CODE='');env.pop('AVELIS_ENV',None)
p=subprocess.Popen([sys.executable,'-m','uvicorn','server:app','--host','127.0.0.1','--port','8768','--no-proxy-headers'],cwd=root,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
 for i in range(40):
  try:urllib.request.urlopen('http://127.0.0.1:8768/api/status',timeout=1);break
  except Exception:time.sleep(.25)
 with sync_playwright() as pw:
  browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=browser.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  session=requests.Session();base='http://127.0.0.1:8768';static=root/'static';
  def bridge(path,method,body):
   r=session.request(method,base+path,headers={'Origin':base,'X-Avelis-Request':'1','Content-Type':'application/json'},data=body,timeout=15);return {'ok':r.ok,'status':r.status_code,'data':r.json()}
  page.expose_function('serverBridge',bridge)
  def mount(name):
   # Render the real static assets with API fetch bridged to HTTP server via Python.
   html=(static/name).read_text();html=html.replace('<link rel="stylesheet" href="/assets/site.css">','<style>'+ (static/'site.css').read_text()+'</style>');
   html=re.sub(r'src="/assets/([^"]+\.(?:png|webp))"',lambda m:'src="data:'+mimetypes.guess_type(m[1])[0]+';base64,'+base64.b64encode((static/m[1]).read_bytes()).decode()+'"',html)
   html=re.sub(r'<script[^>]*src="/assets/([^"]+)"[^>]*></script>','',html)
   page.set_content(html,wait_until='domcontentloaded');page.evaluate("""(()=>{window.fetch=async (path,opts={})=>{const r=await window.serverBridge(path,opts.method||'GET',opts.body||null);return {ok:r.ok,status:r.status,json:async()=>r.data}};})()""")
   assets={x.name:'data:'+mimetypes.guess_type(x.name)[0]+';base64,'+base64.b64encode(x.read_bytes()).decode() for x in static.iterdir() if x.suffix in ('.png','.webp')}
   page.evaluate("""assets=>{new MutationObserver(()=>document.querySelectorAll('img[src^=\"/assets/\"]').forEach(el=>{let x=assets[el.getAttribute('src').split('/').pop()];if(x)el.src=x})).observe(document.documentElement,{childList:true,subtree:true})}""",assets)
   page.add_script_tag(content=(static/('public.js' if name=='index.html' else 'app.js')).read_text())
  mount('index.html');page.get_by_role('heading',name='Intelligence behind every connection.').wait_for(timeout=10000);page.screenshot(path='/mnt/data/Avelis_AI_Homepage_Preview.png');print('PASS public page rendered')
  page.locator('#interest input[name=name]').fill('Preview test');page.locator('#interest input[name=email]').fill('test@example.com');page.locator('#interest input[name=company]').fill('Fictional B2B');page.locator('#interest input[name=consent]').check();page.locator('#interest button').click();page.locator('#form-status').filter(has_text='recorded').wait_for();print('PASS early access registration')
  page.evaluate("location.hash='register'");mount('app.html');page.locator('#auth-form input[name=name]').fill('Avelis Reviewer');page.locator('#auth-form input[name=company]').fill('Sample Workspace (fictional)');page.locator('#auth-form input[name=email]').fill('reviewer@example.com');page.locator('#auth-form input[name=password]').fill('TestPassword123!');page.locator('#auth-submit').click();page.get_by_role('heading',name='Command Centre',exact=True).wait_for(timeout=15000);print('PASS register and open actual workspace')
  def nav(n):page.locator(f'[data-view="{n}"]').click()
  def save():page.locator('#record-form button[type=submit]').click();page.get_by_text('Record saved.',exact=True).wait_for()
  nav('contacts');page.locator('#record-form input[name=name]').fill('Sample Customer');page.locator('#record-form input[name=company]').fill('Example Business');save();page.locator('#records-table').get_by_text('Sample Customer').wait_for();print('PASS CRM creation visible')
  nav('deals');page.locator('#record-form input[name=title]').fill('Sample integration project');page.locator('#record-form select[name=contact]').select_option(label='Sample Customer');page.locator('#record-form input[name=amount]').fill('12500');page.locator('#record-form select[name=stage]').select_option('Proposal');page.locator('#record-form input[name=probability]').fill('60');save();page.locator('#records-table').get_by_text('Sample integration project').wait_for();nav('overview');page.get_by_text('$7,500.00',exact=True).wait_for();page.screenshot(path='/mnt/data/Avelis_AI_Workspace_Preview.png');print('PASS forecast dashboard')
  nav('link');page.locator('#msg-form textarea').fill('Sample test message from workspace');page.locator('#msg-form button').click();page.locator('#msgs').get_by_text('Sample test message from workspace').wait_for();print('PASS workspace messaging')
  nav('advisor');page.locator('#csv-file').set_input_files({'name':'test.csv','mimeType':'text/csv','buffer':b'category,latency\nA,100\nA,200\nB,300\n'});page.locator('#csv-form input[name=metric]').fill('latency');page.locator('#csv-form input[name=group]').fill('category');page.locator('#csv-form button').click();page.locator('#csv-desc').filter(has_text='3 valid').wait_for();print('PASS actual CSV analysis UI')
  page.set_viewport_size({'width':390,'height':844});page.locator('#menu').click();page.locator('[data-view="overview"]').click();page.get_by_role('heading',name='Command Centre',exact=True).wait_for();page.screenshot(path='/mnt/data/Avelis_AI_Mobile_Preview.png');assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1');print('PASS mobile navigation and width')
  assert not errors,errors;print('PASS no uncaught browser JavaScript errors');browser.close()
finally:p.terminate();p.wait(timeout=5);tmp.cleanup()
