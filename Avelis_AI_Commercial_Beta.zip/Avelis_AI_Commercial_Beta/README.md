# Avelis AI — Commercial Beta Foundation

A new server-backed early-access application and public marketing site. **This is a functional restricted-beta release, not an independently security-audited commercial launch.** It does not require an external service to run core CRM, contacts, tasks, messages, analytics, manual integration observations and internal invoice records. No customers or revenue are seeded. The browser screenshots use fictional test records.

## What was retained

`demo.html` is the exact previous main-branch website (GitHub blob `c1772a26597daf1e2e330764ba8dd38cf4d840ac`, 638,438 UTF-16 code units, FNV-1a 1713276846). Original Avelis, Ditheka, Amā and Sharim logos are extracted unchanged from the previous site. Existing demo, pricing, governance, Advisor CSV analysis, pilot configuration and Sharim Card Studio remain intact there. In production `/demo` redirects to the existing GitHub Pages URL, keeping that public prototype off the authenticated application's origin. In development `/demo` serves the preserved copy. Do not publish the new server application source in the public repository. The existing GitHub Pages address has NOT been changed by this release.

## Run on your own computer

Install Python 3.12 or newer. Extract the ZIP and open a terminal inside `Avelis_AI_Commercial_Beta`.

```sh
python -m venv .venv
# macOS/Linux: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m uvicorn server:app --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000/ in a browser. Open Sign in, switch to Create a workspace, and register a fictional email/company and unique password (12+ characters). Local development defaults to open registration and an insecure HTTP cookie suitable only for localhost. Choose a different port only if you also change AVELIS_ORIGIN. Never run this development mode on a public network. Records persist in `data/avelis.db`; this file is not shipped or committed.

## Deploy the restricted beta

**Do not just replace index.html in GitHub Pages.** GitHub Pages cannot run Python or persist a private server database. The old public site can stay at its existing URL.

1. Create a new PRIVATE repository and upload the contents of this release, including Dockerfile, `server.py`, `admin.py`, `demo.html`, and `static/`. Do not upload `.env`, API keys, data, logs or a virtual environment.
2. Use a managed Docker-capable web host with HTTPS and a persistent disk mounted at `/data`. Set one web-service instance, one worker and an appropriate resource budget. SQLite is intended for this small single-instance beta; migrate to managed PostgreSQL for wider adoption.
3. Configure the secret environment values from `.env.example` through the host's secret settings. Set `AVELIS_ORIGIN` to the exact externally visible HTTPS origin, `AVELIS_ENV=production`, `AVELIS_DB=/data/avelis.db`, and `AVELIS_BETA_CODE` to a unique random code at least 24 characters long. Generate a code using `python -c "import secrets; print(secrets.token_urlsafe(32))"`. The application refuses to start without secure production settings. Ensure the volume is writable by container UID 10001; do not use ephemeral storage.
4. Verify the hosted homepage, sign-in, team invitations, data persistence across redeployments, cross-company isolation, CSRF restrictions, and HTTPS cookies. Use fictional records only until security, privacy and legal checks are complete. Configure backups and verify recovery; do not rely on an unmanaged SQLite file as a production backup strategy.
5. Keep the early access list private. Manually verify beta applicants, then share your beta invitation code privately, or generate an email-bound single-use teammate invitation inside the application. The organization creation code is shared and must be rotated if leaked. Email-based verification, recovery, MFA and automatic emails are not implemented. Do not advertise open self-serve registration yet.
6. After a deployed smoke test, add a link from your existing GitHub Pages homepage to the hosted application, so the original OBSIDI link continues to work. Do not replace the old website with the new public HTML alone.

The Docker image uses Python 3.12, an unprivileged account, and a single uvicorn worker. Review dependency versions and scan the image before rollout. Rate limiting uses the direct connection address; when behind a reverse proxy several clients may share a limit. Configure host-level rate limiting and trusted proxy settings deliberately.

## Operator commands (private server shell)

Use the same environment and database path as the application. These tools are not exposed through HTTP. Handle exports as private data.

```sh
python admin.py leads > early-access.csv
python admin.py members
python admin.py remove-lead --email example@example.com --confirm
python admin.py disable-member --email member@example.com --confirm
```

The last command revokes sessions and disables login for a member, preserving their activity records. Owner transfer, deletion, data-subject access requests and full retention/deletion tooling need further implementation and documented processes. Do not collect sensitive/regulated information before these are reviewed.

## Actual functionality in the new private beta

- Persistent SQLite records scoped to authenticated organization, owner/member roles, scrypt password hashing, random hashed session tokens, httpOnly cookies, server-side permission checks and basic request throttling.
- Public early-access interest form records consent and stores contact information in the server database; operator can export leads. No public waitlist count.
- Amā Relations: create/edit/search contacts and opportunities, weighted pipeline calculation, CSV export.
- Amā Link: company-wide channels, shared persisted messages synchronized by polling every five seconds, message-to-task action; not private channels or streaming calls.
- Amā Teams and Flow: assigned tasks, due dates, statuses, reusable task sequence that can be run once. No unattended outbound messages or general automation engine.
- Amā Commerce: invoice records created from won deals, duplicate prevention, owner-only recording of independently verified external payment receipts. Not actual payment processing, tax invoices or a ledger.
- Advisor: numerical CSV analysis on the server, grouping, report export; file data not persisted. Use nonsensitive datasets until privacy/security review. Live dashboards aggregate stored records.
- Avelis integration observations: manual measured status and latency entries; not live API monitoring.
- Audit events record major mutations. Not a certified immutable audit system.
- Optional live model adapter uses OpenAI Responses API (`https://api.openai.com/v1/responses`), with server environment variables `OPENAI_API_KEY` and `OPENAI_MODEL`, limit and explicit opt-in for aggregate metrics. The model is not connected by default. Do not assume external provider retention policies from `store:false`; review contractual data processing, cost controls and consent. No real model requests were made in tests.
- `Connect & Discover` and `Sharim` pages explicitly state which services are not configured, with real internal alternatives and links to the old prototype. No simulated transactions mix with actual workspace records.

## Not commercial-production-ready yet

Live telecom, meeting recording/transcription, licensed business contact enrichment, external email and calendar integrations, streaming chat/private channels, billing/subscriptions, automated monitoring, actual bank/payment integrations and Sharim hardware require further work, external accounts/agreements, regulatory review where relevant, and integration testing. Avelis and Amā do not have real customer adoption merely because this source exists. No platform should claim these features are operational in an advertisement.

Before accepting genuine business data: independently review application security and privacy; add email verification/password recovery/MFA, granular authorization, account lifecycle/record deletion, data-retention policy and terms, encryption at rest at hosting layer and backups, incident response, operational monitoring, dependency/penetration testing, access logs and support processes. Ensure multi-companies and billing are validated. This is intentionally a limited invitation-only technical foundation. No live deployment or service credentials were provided; nothing has been purchased, configured or published remotely.

## Tests

`TEST_RESULTS.txt` records 30 backend checks and 9 browser-harness checks on temporary databases. Browser navigation was blocked in the generation environment, so the harness rendered the original HTML/CSS/JS and bridged browser requests to the running HTTP API with a Python session (not actual browser cookie/CSP enforcement). Direct browser smoke test must still be run on the deployed host. Run `PYTHONPATH=. python tests/test_backend.py` with `httpx` installed. The browser tests additionally require Playwright and Chromium, and the harness requires `requests`. Change screenshot output paths to your workspace if running outside this environment. Direct navigation test is provided for a real environment where localhost works. API tests are not a security audit.
