# Avelis AI — Repaired connected prototype (GitHub Pages)

Avelis AI — Intelligence Behind Every Connection. Developed under Ditheka Intelligence. Original transparent logos for both organizations are included as provided.

## What changed in this repair
- Updated the browser's stored-state restoration so incomplete old demo records don't break navigation.
- Fixed the proposed-pricing calculator so add-ons selected in Billing & Resources update the public pricing estimate and vice versa.
- Retained safe, nonsecret URL query parameters when storing example integration documentation URLs (not fetched or validated externally).
- Made the demo integration record limit follow the selected proposed plan and extra integration add-on.
- Replaced inquiry's clipboard-only action with an email draft link, downloadable text draft, and optional copy button. No inquiry is sent automatically and there is no recipient email configured.
- Improved mobile interaction hit targets and Safari file download timing.
- Hardened CSV export against spreadsheet formula interpretation.

## Files to deploy
**Simplest:** Use the separate standalone file `Avelis_AI_Repaired_index.html` (also provided as `index.html`) to **replace the root `index.html`** in `Bliuew/avelis-ai` on `main`.

This ZIP is the editable, multi-file source. If using the ZIP source, extract and upload `index.html`, `styles.css`, `script.js`, and the `assets` folder to the repository root, keeping file paths unchanged. GitHub Pages does not unpack uploaded ZIP files automatically.

## Tested
Local Chromium automated checks at 1280px and 390px: both brand logos; all 11 Command Centre destinations; example integration registration, query preservation and approval/simulation flows; multi-screen pricing sync; inquiry draft download; CSV audit export; local saved progress after a reload. No script errors observed in these tests. Testing does not establish universal browser or server compatibility.

## Honesty about capabilities
This is a **browser-based prototype**, not a deployed AI backend. It supports interactive local records, approvals, fictional incidents, limited rules-based assistant responses, proposed pricing, and exports. It does **not** use a live generative model, connect to actual REST/MCP services, verify integrations, send inquiry emails or team invitations automatically, authenticate users, enforce production security or process payments. Sample incident data and simulations are fictional. Do not enter credentials or confidential information.

A real enterprise service requires a secure backend, authentication, tenant isolation, server-side policy enforcement, secrets management, integration execution, external monitoring, AI model access and a real audit data store. GitHub Pages alone cannot provide these.
