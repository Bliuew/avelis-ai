# Avelis AI — Advisor™ + invited reviewer launch kit

**Prepared November 16, 2026.** Built as an additive update to the corrected Avelis AI prototype. The original Avelis AI and Ditheka Intelligence image assets, branding, hero, 11-section Command Centre, existing navigation, pricing and contact-draft functionality are preserved.

## What is already functional

**Existing source baseline (before this kit):** responsive public website, original logos, browser-local integration registry and approvals, fictional incidents, rules-based assistant preview, 7 specialist descriptions, onboarding milestones, billing illustration, audit/JSON/CSV exports, and email inquiry draft preparation. This is NOT a generative AI or production integration service.

**New public Advisor™ preview (works without any backend):**
- Load a built-in **synthetic** CSV dataset (63 fictional connector records), or select a visitor's own CSV file, **without uploading it**.
- Strict CSV parsing (quoted comma and multiline field support; unique headers; rejects ragged or malformed rows); limits: **3 MB / 5,000 rows / 40 columns**.
- Select numeric metric and optional category; calculate real record counts, missing values, sum, mean, median, min, max and interpolated P95; visualize group averages; show explicit, deterministic observations.
- Download findings as CSV, or a printable HTML report that can be saved as PDF by the visitor. User-controlled values are inserted into HTML safely, and CSV spreadsheet-formula injection is mitigated.
- The code calls **no AI model, analytics API or server** and makes no misleading claims of AI. Only safe synthetic data is provided.

**New pilot invitation and reviewer UI:**
- Consent-based registration form on public website, **disabled until configured** with a real backend HTTPS URL and public privacy contact email.
- Link to invited-reviewer sign-in, only shown after configuration.
- Server implementation in `backend/`, using Cloudflare Workers and D1 (not GitHub Pages), with server-side invite verification, PBKDF2-SHA256 hashed passwords, secure HttpOnly SameSite Strict cookies, expiring database-backed sessions, origin checks, and per-IP pseudonymized rate limits.
- Pilot registration persists genuine consented interest in private D1. No fictitious submissions are seeded.
- Reviewer portal requires server authentication; displays development milestones, a live hypothetical arithmetic business scenario, a deterministic integration-risk triage and downloadable scenario summary, and **only founder-verified commercial metrics** from private D1. Empty table says *not reported*, not *zero*.

## Artifact structure

- `public/index.html`, `public/styles.css`, `public/script.js`, `public/advisor.css`, `public/advisor.js`, `public/assets/`: editable website source.
- `Avelis_AI_Advisor_Public_index.html`: **single-file** version for the existing GitHub Pages repository; original logos and all styles/scripts embedded. Use this file to replace the repository root `index.html`.
- `backend/src/worker.js`, `backend/src/logos.js`: **private** Worker; logos contain only branding, no reviewer details or credentials.
- `backend/migrations/0001_init.sql`: database schema. No commercial metrics or users are seeded.
- `backend/scripts/create-reviewer.mjs`: creates a password-hash SQL file with credentials supplied via local environment variables.
- `public/assemble.py`, `public/configure_backend.py`: assemble the single-file version and configure **public** Worker URL and privacy contact after deployment.

**DO NOT UPLOAD THE ENTIRE KIT TO THE PUBLIC GITHUB REPOSITORY.** Upload ONLY `Avelis_AI_Advisor_Public_index.html` (renamed `index.html`), or the files under `public/` for a multi-file deployment. Keep backend code, reviewer evidence, emails and invitation files separate in private infrastructure. The Worker source itself has no secrets; private data is in D1 and managed secrets.

## Step 1: Update the public preview (safe before backend launch)

1. Keep a backup of the currently live root `index.html` in the `Bliuew/avelis-ai` repository.
2. In the repository on `main`, replace `index.html` with the provided `Avelis_AI_Advisor_Public_index.html` (rename it to `index.html`).
3. Wait for GitHub Pages to complete deployment. Visit `https://bliuew.github.io/avelis-ai/#advisor-preview` and test **Load fictional sample dataset**; switch from `latency_ms` to `errors`, change category, download the two reports.
4. Test the 11 Command Centre panels and the existing inquiry draft. The pilot registration button correctly remains disabled pending server deployment.
5. Do not place personal/customer data in the Command Centre demo browser storage, or sensitive CSV data in demo screenshots/exports.

## Step 2: Provision private backend (must be done by the Cloudflare account owner)

Requirements: Cloudflare account, Node.js and npm. All Cloudflare CLI calls below are for the **private backend**, not GitHub Pages.

```sh
cd backend
npm install
npx wrangler login
npx wrangler d1 create avelis-private
```

Copy the returned D1 database ID into `backend/wrangler.toml` in `database_id`. Next:

```sh
npx wrangler d1 migrations apply avelis-private --remote
npx wrangler secret put RATE_LIMIT_SECRET
npx wrangler secret put CONTACT_EMAIL
npx wrangler deploy
```

Generate a long random value locally for `RATE_LIMIT_SECRET` (never commit it), and use a **real monitored company privacy contact mailbox** for `CONTACT_EMAIL`. The Worker will refuse pilot submissions without either setting. `wrangler deploy` returns an HTTPS `workers.dev` URL.

Official documentation: https://developers.cloudflare.com/d1/get-started/ and https://developers.cloudflare.com/workers/wrangler/commands/d1/

Before opening registration to the public, establish and publish a real privacy notice and retention/deletion process. Conduct an access/security review; this kit is a secure-by-design starter, **not a security audit or compliance certification**.

## Step 3: Create a reviewer invitation privately

Never put a reviewer password in public files, the browser HTML, a URL, or a tracked git commit.

```sh
cd backend
# Set REVIEWER_EMAIL, REVIEWER_PASSWORD (>= 16 chars), REVIEWER_NAME as local environment variables.
node scripts/create-reviewer.mjs reviewer-invite.private.sql
npx wrangler d1 execute avelis-private --remote --file=reviewer-invite.private.sql
# Securely send the reviewer their credentials; securely delete the local .sql file.
```

Credentials are salted/hashed before D1 insertion; sessions expire after eight hours, can be revoked by deleting sessions in D1, and are not managed by GitHub Pages. For confidential investor diligence, add Cloudflare Access identity verification with MFA and invite revocation before opening real proprietary information.

## Step 4: Connect the public pilot form

After deploying the Worker, use the public configuration helper from inside `public/`:

```sh
cd public
python configure_backend.py https://YOUR-WORKER.SUBDOMAIN.workers.dev privacy@YOURDOMAIN.com
```

It generates `avelis-ready-for-github-index.html`. Upload that output as the public root `index.html`. This configures **only a public URL and email address**—never secrets.

Check the form by sending a test opt-in with explicit consent; the Worker returns confirmation only after storing it in private D1. Test the reviewer URL separately with an invited account. Remove test registrations from D1 and never call them customer traction.

## Step 5: Enter honest, evidence-backed traction

There are **no invented customer counts, partners, or revenues**. `verified_metrics` starts empty. Only the founder/admin should add records backed by actual evidence, directly via their private database admin environment, e.g. with SQL parameters or safely escaped SQL. Record a label, value, evidence description and verification date. Examples of legitimate future metrics: consented pilot interest count from D1 after deduplication and spam filtering; number of completed interviews with permission; paid pilot contracts supported by signed documentation. None are seeded or claimed today.

**Proposed milestones:** public Advisor demo → consensual discovery → secure tenant onboarding → first authorized sandbox connector → measured pilot → commercial validation. These are milestones, not guaranteed dates or existing production features.

## Security and honesty checklist

- Do not place reviewer-only material or passwords in public GitHub Pages, the public `index.html`, code comments, public JS or GitHub release assets.
- Do not claim the rule-based assistant or locally stored integration approvals are real enterprise AI or security enforcement.
- This Worker implements password-based server authentication, but production review should add MFA/SSO, invite revocation UI, audit log retention, secret rotation, back-up, data processing agreements, privacy policy, security testing and incident response.
- Keep D1 in a Cloudflare account controlled by the company. Set appropriate Cloudflare access management and retention.
- The calculator in the reviewer room shows **hypothetical** math driven by reviewer-entered assumptions; never represent those values as measured outcomes.
- Pilot consent/registration is not evidence of paying customers or revenue.

## Local checks performed

- HTML validated for duplicate IDs; original logos are embedded in one-file site.
- Node syntax checks for both public scripts and Worker.
- Headless Chromium desktop (1280px): original logo loads, Advisor sample analyzes 63 records, P95/median/category comparison responds, both report downloads work, malformed data is rejected and data-label HTML is not executed, all 11 original panels navigate, no JavaScript errors.
- Mobile-sized (390px) browser check using a lightweight image replacement during test: analytics works, existing panel navigation works, no horizontal page overflow or JS errors. This does **not** establish full visual verification with original embedded images on real iOS Safari.
- SQLite-backed Worker integration tests: anonymous reviewer blocked, CORS origin checks, real pilot insert on consent, rejection without consent, correct/incorrect password, secure session cookie, private facts view, logout and session revocation.

**Nothing has been deployed by the assistant** to GitHub or Cloudflare. The private backend has not been provisioned; the review portal is not yet accessible online and live pilot signup is disabled until configuration.


## New: Interactive investor-grade visual dashboard (November 2026)

The original website design, logos, Command Centre workflows, advisor CSV parser, pilot/backend architecture, and explicit demo disclosures remain. Added a dark wine/gold **Visual Intelligence Command Centre** based on the user's reference layout, with four calculated KPIs, responsive bar charts with 7/14/21 dataset-period controls, a computed donut chart (sample error-rate bands or uploaded-data completeness), category tables, browser-only activity, exportable snapshot, and Advisor chart synchronization.

Advisor™ now loads the clearly labeled fictional dataset by default, so the graphs appear as soon as someone arrives. Uploading a CSV recalculates the Advisor graphs and the Command Centre dashboard from the selected file. No CSV is transmitted, retained on a server, or claimed as live activity. Error bands are illustrative interpretations of input **errors / requests** figures, not verified uptime, security, or real system status. The public demo requires no backend; the invite-only reviewer infrastructure continues to require deployment.

To publish: upload only the final single-file `index.html` to the public repository root. **Do not upload the backend or reviewer evidence to the public repo.**
